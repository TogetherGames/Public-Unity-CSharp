using UnityEngine;
using System.Collections;
using PlaysTogether;
	
public class TogetherPlatform : MonoBehaviour
{
	private static TogetherPlatform _instance = null;
	
	private static bool _initialized = false;
	private static PlaysTogether.Together _together;
	
	public string PublicKey = "";
	public string PrivateKey = "";
	public string GameKey = "";
	public string FacebookAppID = "";
	public bool PushServiceEnabled = false;
	public string GCM_ProjectID = "";
	private TogetherFacebook _fb = null;
	
	private void Start()
	{
		if(_instance != null)
			GameObject.Destroy(gameObject);
		else
		{
			DontDestroyOnLoad(this);
			
			Initialize();
			
			if(FacebookAppID != "")
			{
				_fb = (TogetherFacebook)gameObject.AddComponent(typeof(TogetherFacebook));
				_fb.Initialize(FacebookAppID);
				DontDestroyOnLoad(_fb);
			}
			
			if(PushServiceEnabled)
			{
				TogetherDeviceRegistrar reg = (TogetherDeviceRegistrar)gameObject.AddComponent(typeof(TogetherDeviceRegistrar));
#if UNITY_IPHONE				
				reg.Initialize();
#endif
#if UNITY_ANDROID
				reg.Initialize(GCM_ProjectID);
#endif
			}
		}
	}
	
	private void Initialize()
	{
		if(!_initialized)
		{
			_instance = this;
			
			PlaysTogether.Log.Instance = new TogetherLog();
			PlaysTogether.CacheFile.Instance = new TogetherCache();
			((TogetherCache)PlaysTogether.CacheFile.Instance).PersistentDataPath = Application.persistentDataPath;
	
			//Store an instance of the together platform
			_together = new Together(false);
			
#if UNITY_IPHONE
			_together.Initialize(PublicKey, PrivateKey, GameKey, "iOS");
#endif
#if UNITY_ANDROID
			_together.Initialize(PublicKey, PrivateKey, GameKey, "Android");
#endif
			
			_together.LoadTogetherCache();
			_initialized = true;
		}
	}
	
	private void Update() 
	{
		PlaysTogether.NetworkProcessor.Process();
	}
	
	public void OnMessageAndroid(string message)
	{
		Debug.Log ("OnMessageAndroid() - message=" + message);
	}

}
