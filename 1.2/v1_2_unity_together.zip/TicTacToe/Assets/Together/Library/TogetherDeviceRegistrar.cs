using UnityEngine;
using System.Collections;
using PlaysTogether;
using System;

public class TogetherDeviceRegistrar : MonoBehaviour
{
#if UNITY_IPHONE
	private byte[] _token = null;
	
	public void Initialize()
	{

		Debug.Log ("Registering device...");
		NotificationServices.RegisterForRemoteNotificationTypes(
			RemoteNotificationType.Alert | RemoteNotificationType.Badge | RemoteNotificationType.Sound);
	}
	
	private void Update()
	{
		string regErr = NotificationServices.registrationError;
		if(regErr != null && regErr != "")
		{
			Debug.Log ("Device Registration Error: " + regErr);
			Destroy(this);
			return;
		}
		
		if(Together.Instance != null && Together.Instance.UserSession != null)
		{
			_token = NotificationServices.deviceToken;
			if(_token != null)
			{
				string hexToken = System.BitConverter.ToString(_token).Replace("-", "");
				Together.Instance.ApnsDeviceToken = hexToken;
				Together.Instance.RegisterPushEnabledDevice(null);
				Destroy(this);
			}
		}
	}
#endif
	
	
#if UNITY_ANDROID
	private string _token = "";
	
	public void Initialize(string ProjectID)
	{
		AndroidJavaClass unityPlayer = new AndroidJavaClass ("com.unity3d.player.UnityPlayer");
		AndroidJavaObject currentActivity = unityPlayer.GetStatic<AndroidJavaObject> ("currentActivity");
		AndroidJavaClass regclass = new AndroidJavaClass ("com.playstogether.gcm.RegisterActivity");

		regclass.SetStatic<string>("ProjectID", ProjectID);
		
		try{
			regclass.CallStatic ("RegisterDevice", currentActivity);
		}
		catch(Exception e)
		{
			OnError(e.Message);
		}
	}
	
	private void Update()
	{
		if(Together.Instance != null && Together.Instance.UserSession != null)
		{
			if(_token != "")
			{
				Together.Instance.GcmDeviceToken = _token;
				Together.Instance.RegisterPushEnabledDevice(null);
				Destroy(this);
			}
		}
	}
	
	public void OnRegisteredAndroidDevice(string deviceID)
	{
		_token = deviceID;
	}
	
	public void OnPreRegisteredAndroidDevice(string deviceID)
	{
		_token = deviceID;
	}
	
	public void OnUnregisteredAndroidDevice(string deviceID)
	{
		_token = "0";
	}
	
	public void OnError(string errorID)
	{
		Debug.Log ("OnErrorAndroid() - errorID=" + errorID);
		Destroy(this);
	}
#endif
}
