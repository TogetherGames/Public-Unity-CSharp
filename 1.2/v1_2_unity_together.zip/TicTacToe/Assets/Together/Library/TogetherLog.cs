using UnityEngine;
using PlaysTogether;

public class TogetherLog : Log
{

	public TogetherLog()
	{
		_enabled = true;
	}
	
	public override void Print(string msg)
	{
		if (_enabled)
			Debug.Log(msg);
	}
}
