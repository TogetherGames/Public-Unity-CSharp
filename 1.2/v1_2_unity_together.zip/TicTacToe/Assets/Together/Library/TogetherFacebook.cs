using UnityEngine;
using System.Collections.Generic;
using PlaysTogether;
using PlaysTogether.Social;
using PlaysTogether.Social.FBObjects;

public class TogetherFacebook : MonoBehaviour
{
	// Exposed in editor
	public string FacebookApplicationID;

	
	public static TogetherFacebook Instance;
	
	/// The Facebook Wrapper
	//private static Facebook _fb;
	
	// Poll handlers
	private float _pollTime = 3f;
	private OnCompleteHandler _pollCallback = null;
	private TogetherCallback _togetherResponse = null;
	
	// Accessors to the Facebook Wrapper
	public fboMe Me				{	get{	return Together.Instance.Social.Facebook.Me;				}}
	public string AccessToken	{	get{	return Together.Instance.Social.Facebook.AccessToken;		}}

	public int GetFacebookFriendCount()
    {
		return Together.Instance.Social.Facebook.GetFacebookFriendCount();
    }

    public ExternalFriend GetFacebookFriend(int index)
    {
		return Together.Instance.Social.Facebook.GetFacebookFriend(index);
    }
	
	public ExternalFriend FindBySocialID(string socialID)
	{
		return Together.Instance.Social.Facebook.FindBySocialID(socialID);
	}
	
	public void DumpFriends()
	{
		Together.Instance.Social.Facebook.DumpFriends();
	}
	
	private void Start()
	{
	}
	
	public void Initialize(string FacebookAppID)
	{
		Instance = this;
		this.FacebookApplicationID = FacebookAppID;
		if(Together.Instance.Social != null)
		{
			Debug.Log("FB Initialize");
			//_fb = Together.Instance.Social.Facebook;
			Together.Instance.Social.Facebook.Initialize(FacebookApplicationID);
		}
	}
	
	//-------------------------------------------------
	// Poll Loop
	//-------------------------------------------------
	private void Update ()
	{
		if(_pollCallback != null)
		{
			if(_pollTime > 0f)
			{
				_pollTime -= Time.deltaTime;
				if(_pollTime <= 0f)
					Together.Instance.Social.Facebook.QueryActions(onActionsQueried);
			}
		}
		
		if(_togetherResponse != null)
		{
			Debug.Log("_togetherResponse is not null!");
			
			if(_pollCallback != null)
				_pollCallback(_togetherResponse);
			
			_pollCallback = null;
			_togetherResponse = null;
		}
	}
	
	private void onActionsQueried(TogetherCallback e)
	{
		if(e.Success)
		{
			FBQueryResponse res = (FBQueryResponse)e.Data;
			if(res.Success)
				_togetherResponse = e;
			else
				_pollTime = 3f;
		}
		else
			_pollTime = 3f;
	}
	
	

	//-------------------------------------------------
	// Commands
	//-------------------------------------------------
	
	
	// Login to facebook(Dialog)
	//-------------------------------------------------
	public void Login(OnCompleteHandler callback)
	{
		Debug.Log("TogetherFacebook::Login()");
		if(_pollCallback == null)
		{
			_pollCallback = callback;
			_pollTime = 3f;
			
			Application.OpenURL(Together.Instance.Social.Facebook.GetAuthURL());
		}
		else
			callback(new TogetherCallback(false, "Failed", "Facebook is still working at this time.", null));
	}
	
	
	// Logout of facebook(Silent)
	//-------------------------------------------------
	public void Logout(OnCompleteHandler callback)
	{
		Debug.Log("TogetherFacebook::Logout()");
		Together.Instance.Social.Facebook.Logout(callback);
	}
	
	
	// Send a post to your own wall(Silent)
	//-------------------------------------------------
	public void SendPost(string postName, string postDescription, string postMessage, string postPictureLink, string postCaption, OnCompleteHandler callback)
	{
		Debug.Log("TogetherFacebook::SendPost()");
		Together.Instance.Social.Facebook.SendPost(postName, postDescription, postMessage, postPictureLink, postCaption, callback);
	}
	
	
	// Post to a friend's wall(Dialog)
	//
	// Usage:
	//	TogetherFacebook.Instance.SendPostToUser(m_FacebookFriend, "This is the Post Name", "This is the descrpition", "This is the message", "http://google.com", "", onPostedToFriend);
	//
	//-------------------------------------------------
	public void SendPostToUser(ExternalFriend who, string postName, string postDescription, string postMessage, string postLink, string postPictureLink, OnCompleteHandler callback)
	{
		Debug.Log("TogetherFacebook::SendPostToUser()");
		if(_pollCallback == null)
		{
			_pollCallback = callback;
			_pollTime = 3f;
			
			Application.OpenURL(Together.Instance.Social.Facebook.GetPostURLParams((int)Application.platform, who.FriendID, postName, postDescription, postMessage, postLink, postPictureLink));
		}
		else
			callback(new TogetherCallback(false, "Failed", "Facebook is still working at this time.", null));
	}
}