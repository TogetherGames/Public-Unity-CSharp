using UnityEngine;
using System.Collections;
using PlaysTogether;

public class GameInstance : MonoBehaviour
{
	private const int REFRESH_TIME = 7;
	private float waitTime = 0;
	
	[SerializeField] Texture2D idleTile;
	[SerializeField] Texture2D xTile;
	[SerializeField] Texture2D oTile;
	
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private int m_nGridWidth = 3;
	private int m_nGridHeight = 3;
	private int buttonYStart = 400;

	private bool m_bXplayer;
	private bool m_bLeftGame = false;
	
	//data for textfields
	private string m_userName;
	private float m_ID;
	private int m_playCount ;
	
	//Game grid of textures
	private Texture2D[,] m_gridTextures;
	private PlaysTogether.GameInstance m_GameInstance = null;
	private string m_GameData = "_________";
	private string m_WinCondition = "";
	private string m_DisplayDialog = "";
	private bool m_CreateDialog = false;


	// Use this for initialization
	void Start () 
	{
		m_GameInstance = Helper.UserData as PlaysTogether.GameInstance;
		
		//The color and style for text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		m_gridTextures = new Texture2D[m_nGridHeight, m_nGridWidth];
		
		for (int col = 0; col < m_nGridHeight; col++) 
		{
			for (int row = 0; row < m_nGridWidth; row++) {
				m_gridTextures[col,row] = idleTile;
			}
		}
		RefreshGame();
	}
	
	// Update is called once per frame
	void Update () 
	{
		waitTime += Time.deltaTime;

		if( waitTime >= REFRESH_TIME)
		{
			waitTime = 0;
			RefreshGame();
		}
		
		if(m_bLeftGame)
		{
			Application.LoadLevel("GameLobby");
			m_bLeftGame = false;
		}
	}
	
	void OnGUI()
	{
		//Display all of our text fields!
		DisplayText();
		//Display our buttons
		DisplayButtons();
	}
	
	void DisplayText()
	{
		int userTurnIndex = GetTurnIndexForUser(Together.Instance.User.UserID);
		bool myTurn = IsMyTurn ();
		
		//Create and set the Labels
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 15, 300,100), "Game Instance ", m_TitleStyle);	
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 80, 300, 50), "ID = " + m_ID , m_TextStyle);	
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 110, 300, 50), "UserIndex = " + userTurnIndex, m_TextStyle);	
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 140, 300, 50), "TurnIndex= " + m_GameInstance.TurnIndex, m_TextStyle);	
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 170, 300, 50), "PlayCount = " + m_playCount, m_TextStyle);	
		
		if (myTurn)
			GUI.Label(new Rect((Screen.width - 300) * 0.5f, 230, 300, 50), "Your Turn", m_TextStyle);	
		else
			GUI.Label(new Rect((Screen.width - 300) * 0.5f, 230, 300, 50), "Not Your Turn", m_TextStyle);	

	
		int labelY = 270;

		GameInstanceUser gameInstanceUser;
		
		for (int i=0; i<m_GameInstance.GetGameInstanceUserCount(); i++)
		{
			gameInstanceUser = m_GameInstance.GetGameInstanceUser(i);
			
			GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 50),
				gameInstanceUser.Name + ", Score=" + gameInstanceUser.Properties.GetEx("Score", "0"), m_TextStyle);	

			labelY += 30;
		}
	}
	
	void DisplayButtons()
	{
		if( GUI.Button(new Rect(10, 50, 100, 40), "Back"))
			Application.LoadLevel("GameLobby");
		
		if( GUI.Button(new Rect(10, 100, 100, 40), "Leave Game"))
			OnLeaveButtonClicked();
		
		if( GUI.Button(new Rect(10, 150, 100, 40), "Invite Friend"))
			OnInviteFriendButtonClicked();

		if( GUI.Button(new Rect(10, 200, 100, 40), "Clear Board"))
			OnClearBoardButtonClicked();

		if( GUI.Button(new Rect(10, 250, 100, 40), "Forfeit Game"))
			OnForfeitGameButtonClicked();

		
		int buttonWidth = 100;
		int buttonHeight = 50;
		int buttonX = 0;
		int buttonY = buttonYStart;
		int buttonXSep = 10;
		int buttonYSep = 10;

		for (int row = 0; row < m_nGridWidth; row++) 
		{
			buttonX = (Screen.width - buttonWidth*3 - buttonXSep*2) / 2;
			
			for (int col = 0; col < m_nGridHeight; col++) 
			{
				//Create our buttons with a 2d array of there textures
				if (GUI.Button(new Rect(buttonX, buttonY, buttonWidth, buttonHeight), m_gridTextures[col,row]))
				{
					OnBoardButtonClicked(row, col);
				}
				buttonX += buttonWidth + buttonXSep;
			}
			buttonY += buttonHeight + buttonYSep;
		}

/*
		for (int col = 0; col < m_nGridHeight; col++) 
		{
			for (int row = 0; row < m_nGridWidth; row++) 
			{	
				//Create our buttons with a 2d array of there textures
				if( GUI.Button(new Rect(xoff + (col % 3.0f * 110.0f), yOff + (row * 60), 100, 50), m_gridTextures[col,row]))
				{
					OnBoardButtonClicked(row, col);
				}
			}
		}
*/

		if (m_CreateDialog)
		{
			ShowDialogToDisplay();
			m_CreateDialog = false;
		}
//		if (m_DisplayDialog != "")
//			ShowDialogToDisplay();

/*
		for (int col = 0; col < m_nGridHeight; col++) 
		{
			for (int row = 0; row < m_nGridWidth; row++) 
			{	
				//Create our buttons with a 2d array of there textures
				if( GUI.Button(new Rect(xoff + (col % 3.0f * 110.0f), yOff + (row * 60), 100, 50), m_gridTextures[col,row]))
				{
					//Check win/tie conditions
					switch(CheckForWinCondition())
					{
					case "UserWon":
						Debug.Log("---UserWon---");
						m_GameInstance.Finish(Together.Instance.GetUserID(), onGameFinished);
						Helper.Popup("hmm", "User won!",0);
						break;
					case "OpponentWon":
						Debug.Log("OpponentWon");
						GameInstanceUser opposingGameInstanceUser = GetOpposingGameInstanceUser();
						m_GameInstance.Finish(opposingGameInstanceUser.UserID, onGameFinished);
						Helper.Popup("hmm", "Opponent won!",0);
						break;
					case "Tied":
						Debug.Log("Tied");
						m_GameInstance.Finish(0, onGameFinished);
						Helper.Popup("hmm", "Tie game!",0);
						break;
					case "Move":
						if (IsMyTurn())
						{
							//If there isn't a piece there already make a move
							if( m_gridTextures[col, row] == null)
								MakeTurnInGame(row, col);
						}
						else
							Helper.Popup("hmm", "It's not your turn",0);
						
						break;
					}
				}	
			}
		}
*/
	}
	
	//  Syncs the text displayed on the screen.
	void SyncText()
	{
		Log.Write ("GameInstance.SyncText()");
		Debug.Log ("GameInstance.SyncText() 2");
		m_GameInstance.Dump ();
		m_ID = m_GameInstance.GameInstanceID;
		m_playCount = m_GameInstance.PlayCount;
	}

	//  Syncs the pieces on the board.
	void SyncBoardPieces()
	{
		Debug.Log("****************************   GameInstance.SyncBoardPieces()");

		int dataIndex = 0;
		
		m_GameData = m_GameInstance.Properties.Get("Data").Value;
		Debug.Log("gamedata " + m_GameData);
		
		for (int i = 0; i < m_nGridHeight; i++) 
		{
			for (int j = 0; j < m_nGridWidth; j++) 
			{
				if (m_GameData.Substring(dataIndex,1) == "M")
					m_gridTextures[j,i] = xTile;
				else if (m_GameData.Substring(dataIndex,1) == "O")
					m_gridTextures[j,i] = oTile;
					
				dataIndex++;
			}
		}
	}

	void OnLeaveButtonClicked()
	{
		m_GameInstance.Leave(onGameLeft);
	}

	void OnInviteFriendButtonClicked()
	{
		Debug.Log("OnInviteFriendButtonClicked()");

		FriendLobby.PreviousScreen = "GameInstance";
		Application.LoadLevel("FriendLobby");
	}
	
	void OnClearBoardButtonClicked()
	{
		Debug.Log("OnClearBoardButtonClicked()");

		m_GameData = "_________";
		m_GameInstance.Properties.Set("Data", m_GameData);

		m_GameInstance.Modify (-1, onRefreshGame);
	}
	
	void OnForfeitGameButtonClicked()
	{
		Debug.Log("OnForfeitGameButtonClicked()");
		m_GameInstance.Forfeit(onGameFinished);
	}


	void OnBoardButtonClicked(int row, int col)
	{
		Debug.Log ("GameInstance.OnBoardButtonClicked(" + row + ", " + col + ")");
	
		if (!IsMyTurn())
		{
			m_DisplayDialog = "NotYourTurnDialog";
			m_CreateDialog = true;
			return;
		}

		Debug.Log ("aaaa");
		PlacePieceOnBoard(row, col);

		CheckForUserWinCondition();
		
		Debug.Log ("m_WinCondition = " + m_WinCondition);

		//  If the Game is not over yet, send MakeMove message to the server.
		if (m_WinCondition == "")
		{
			MakeTurnInGame(row, col);
		}			
	}
	
	void CheckForUserWinCondition()
	{
		Debug.Log ("CheckForUserWinCondition()");

		m_WinCondition = CheckForWinCondition();
		
		Debug.Log ("m_WinCondition = " + m_WinCondition);

		//Check win/tie conditions
		switch (m_WinCondition)
		{
			case "UserWon":
				Debug.Log("***  UserWon");
				m_DisplayDialog = "UserWonDialog";
				m_CreateDialog = true;
				break;
			case "OpponentWon":
				Debug.Log("***  OpponentWon");
				m_DisplayDialog = "OpponentWonDialog";
				m_CreateDialog = true;	
				break;
			case "Tied":
				Debug.Log("***  Tied");
				m_DisplayDialog = "TiedDialog";
				m_CreateDialog = true;	
				break;
		}
	}
	
	void ShowDialogToDisplay()
	{
		switch (m_DisplayDialog)
		{
			case "UserWonDialog":
				Helper.Popup("hmm", "You won!  Rematch?", "Yes", "No", 0, PopupDismissed);
				break;
			case "OpponentWonDialog":
				Helper.Popup("hmm", "You lost!  Rematch?", "Yes", "No", 0, PopupDismissed);
				break;
			case "TiedDialog":
				Helper.Popup("hmm", "Tie game!  Rematch?", "Yes", "No", 0, PopupDismissed);
				break;
			case "NotYourTurnDialog":
				Helper.Popup("hmm", "It's not your turn", 0, PopupDismissed);
				break;
		}
	}
	
	void PopupDismissed(string buttonText)
	{
		Debug.Log("GameInstance.PopupDismissed(" + buttonText + ")");
		
		if (m_DisplayDialog == "UserWonDialog" || m_DisplayDialog == "OpponentWonDialog" ||
			m_DisplayDialog == "TiedDialog")
		{
			GameInstanceUser myGameInstanceUser = this.GetMyGameInstanceUser();
			GameInstanceUser opposingGameInstanceUser = this.GetOpposingGameInstanceUser();
		
			long winningUserID = 0;

			if (m_DisplayDialog == "UserWonDialog")
				winningUserID = myGameInstanceUser.UserID;
			else if (m_DisplayDialog == "OpponentWonDialog")
				winningUserID = opposingGameInstanceUser.UserID;
			else if (m_DisplayDialog == "TiedDialog")
				winningUserID = 0;


			//  Want rematch?
			if (buttonText == "Yes")
			{
				PlaysTogether.PropertyCollection rematchGameProps = new PlaysTogether.PropertyCollection();
				rematchGameProps.Set("Data", "_________");
			
				//  Finish and create a rematch GameInstance.
				Together.Instance.GameInstanceManager.CreateRematch(m_GameInstance.GameInstanceID, "", 0, 2,
					winningUserID, winningUserID, true, "",
					m_GameInstance.Properties, myGameInstanceUser.Properties,
					rematchGameProps, onGameFinished);
			}
			else
			{
				//  Just finish the GameInstance.
				m_GameInstance.Finish(winningUserID, onGameFinished);	
			}
		}
	}

	
	
	
	//  Checks for win conditions.  horizontal, vertical, and diagonal
	string CheckForWinCondition()
	{
		int bWon = 0;
		int bOpponentWon = 0;
		
		char user = 'M';
		char opponent = 'O';
		
		//We are not the first user so we must be the O piece
		if(!m_bXplayer)
		{
			user = 'O';
			opponent = 'M';
		}
		
		//Check each direction to see if we won. Add to our count if we have
		bWon += CheckHorizontal(user);
		bWon += CheckVertical(user);
		bWon += CheckDiagonal(user);
		
		if(bWon > 0)
			return "UserWon";
		
		bOpponentWon += CheckHorizontal(opponent);
		bOpponentWon += CheckVertical(opponent);
		bOpponentWon += CheckDiagonal(opponent);
		
		if(bOpponentWon > 0)
			return "OpponentWon";
		
		if(!CanMakeMoveInGame())
			return "Tied";
		
		return "";
	}
	
	//  Checks to see if there is winner in any horizontal row.
	int CheckHorizontal(char piece)
	{
		for (int col = 0; col < m_nGridWidth; col++) 
		{
			int sequence = 0;
			for(int row = 0; row < m_nGridHeight; row++) 
			{
		  		if (m_GameData[col * 3 + row] == piece)
		  		sequence++;
		   	}
			if (sequence == m_nGridWidth ) return 1;
		}
		return 0;
	}

	//  Checks to see if there is winner in any vertical row.
	int CheckVertical(char piece)
	{
		for (int col = 0; col < m_nGridHeight; col++) 
		{
			int sequence = 0;
			for(int row = 0; row < m_nGridWidth; row++) 
		  	{
		  		if (m_GameData[row * 3 + col] == piece)
		  		sequence++;
		   	}
			if (sequence == m_nGridHeight ) return 1;
		}
		return 0;
	}
	
	//  Checks to see if there is winner in any diagonal direction.
	int CheckDiagonal(char piece)
	{
		int sequence = 0;
		int i = 0;
			
		for(i = 0; i < m_nGridWidth; ++i)
		{
			if (m_GameData[i *3 +i] == piece)
				sequence++;
		}
		
		if (sequence == m_nGridHeight)
			return 1;
		
		sequence = 0;
		
		for(i = 0; i < m_nGridWidth; ++i)
		{
			//Our grid height is 3 our array is zerro based. Minus 1 from the length
			int index = (m_nGridHeight - 1) - i;
			if (m_GameData[i * 3 + index] == piece)
				sequence++;
		}
		
		if(sequence == m_nGridWidth)
			return 1;
		
		return 0;
	}

	//  Checks to see if there is a move that can be made.
	bool CanMakeMoveInGame()
	{
		int emptyPieceCount = 0;
		for (int i = 0; i < m_nGridHeight; i++) 
		{
			for (int j = 0; j < m_nGridWidth; j++) 
			{
				if (m_gridTextures[i,j] == null)
					emptyPieceCount++;
			}
		}
		
		if(emptyPieceCount == 0)
			return false;
		
		return true;
	}
	
	//  Places a piece on the board.
	void PlacePieceOnBoard(int row, int col)
	{
		string chPiece = "M";

		//If x player use x texture;
		if (m_bXplayer)
			m_gridTextures[col,row] = xTile;
		else
		{
			chPiece = "O";
			m_gridTextures[col,row] = oTile;
		}

		PlaysTogether.Property gameDataProperty = m_GameInstance.Properties.Get("Data");
		m_GameData = gameDataProperty.Value;

		Debug.Log("GameData = " + m_GameData);

		//Save the state of the board in game data
		string premoveData = m_GameData.Substring(0, row * 3 + col);
		string postmoveData = m_GameData.Substring(row * 3 + col +1);
		m_GameData = premoveData + chPiece + postmoveData;

		Debug.Log("   m_GameData = " + m_GameData);

		m_GameInstance.Properties.Set("Data", m_GameData);
	}

	//  Makes a turn in the game.
	void MakeTurnInGame(int row, int col)
	{
		Debug.Log ("GameInstance.MakeTurnInGame(" + row + ", " + col + ")");

		if (!IsMyTurn())
		{
			Debug.Log("Uh oh, Waiting on user to take there turn");
		}
		else
		{
			Together.Instance.Print(m_GameInstance.Properties.ToString());

			m_GameInstance.MakeMove(onTurnMade);			// callbackFunc
		}	
	}
	void onTurnMade(TogetherCallback tcb)
	{
		if(tcb.Success)
		{
			m_GameInstance.Dump();
			Debug.Log("onTurnmade success");
			
			RefreshGame();
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void RefreshGame()
	{
		Debug.Log("Refresh game");
		m_GameInstance.LastModifyTimestamp = 0;
		m_GameInstance.GetDetails(m_GameInstance.GameInstanceID, onRefreshGame);
	}

	
	void onRefreshGame(TogetherCallback tcb)
	{
		Debug.Log("GameInstance.onRefreshGame()");

		if(tcb.Success)
		{
			m_bXplayer = true;
			if (m_GameInstance.GetTurnIndexForUser(Together.Instance.GetUserID()) > 0)
				m_bXplayer = false;
			
			Debug.Log ("   m_bXplayer = " + m_bXplayer);
			
			SyncBoardPieces();
			SyncText();
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void onGameLeft(TogetherCallback tcb)
	{
		if(tcb.Success)
			m_bLeftGame = true;
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void onGameFinished(TogetherCallback tcb)
	{
		if (tcb.Success)
		{
			Debug.Log("Game Finished ");
			Application.LoadLevel("GameLobby");
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	
	
	//  Gets the TurnIndex for a specific User.
	private int GetTurnIndexForUser(long userID)
	{
		return m_GameInstance.GetTurnIndexForUser(userID);
	}
	
	//  Checks to see if the State of the GameInstance indicates its 'In Progress'.
	bool IsPlaying()
	{
		if (m_GameInstance.State == GameStateMask.IN_PROGRESS)
			return true;
		return false;
	}
	
	//  Checks to is if it is my turn.
	bool IsMyTurn()
	{
		if (m_GameInstance.TurnUserID == Together.Instance.GetUserID())
			return true;
		return false;
	}
	
	//  Gets my User's GameInstanceUser.
	GameInstanceUser GetMyGameInstanceUser()
	{
		Debug.Log ("GameInstance.GetMyGameInstanceUser(), UserID=" + Together.Instance.GetUserID());
		for (int i=0; i<m_GameInstance.GetGameInstanceUserCount(); i++)
		{
			if (m_GameInstance.GetGameInstanceUser(i).UserID == Together.Instance.GetUserID())
				return m_GameInstance.GetGameInstanceUser(i);
		}
		return null;
	}
	
	//  Gets the Opposing
	GameInstanceUser GetOpposingGameInstanceUser()
	{
		for (int i=0; i<m_GameInstance.GetGameInstanceUserCount(); i++)
		{
			if (m_GameInstance.GetGameInstanceUser(i).UserID != Together.Instance.GetUserID())
				return m_GameInstance.GetGameInstanceUser(i);
		}
		return null;
	}

}
