using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using PlaysTogether;

public class Achievement : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private PlaysTogether.Achievement m_Achievement;
	private int textWidth = 500;
	
	// Use this for initialization
	void Start () 
	{
		m_Achievement = Helper.UserData as PlaysTogether.Achievement;
		
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{
		int labelY = 65;
		int labelYStep = 30;

		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 15, 300, 100), "Achievement", m_TitleStyle);
		
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "ActionName = " + m_Achievement.ActionName, m_TextStyle);
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Name = " + m_Achievement.Name, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100),"Description = " + m_Achievement.Description, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Required Count = " + m_Achievement.RequiredCount, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Required Sequential = " + m_Achievement.RequiredSequential, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Required ItemID = " + m_Achievement.RequiredItemID, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Required ItemCount = " + m_Achievement.RequiredItemCount, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Award ItemID = " + m_Achievement.AwardItemID, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Award ItemCount = " + m_Achievement.AwardItemCount, m_TextStyle);	
		labelY += labelYStep;

		// Display all the Achievement properties.
		if (m_Achievement.Properties.Properties != null)
		{
			foreach (Property property in m_Achievement.Properties.Properties)
			{
				GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), property.Name + " = " + property.Value, m_TextStyle);
				labelY += labelYStep;
			}
		}
	}
	
	void DisplayButtons()
	{
		//Create and set the buttons
		if (GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("AchievementsLobby");
		
		if (GUI.Button(new Rect((Screen.width - 100) * 0.5f, Screen.height - 200, 100, 50), "Award"))
		{
			Debug.Log("Award");
			Together.Instance.User.UserAchievementManager.Award(m_Achievement.AchievementID, 		// achievementID
																"", 								// actionName
																0,									// roomID 
																null,//m_Achievement.Properties,			// userAchievementProperties
																"",									// notificationMessage
																onAchievementAwarded);				// callbackFunc
		}
		if (GUI.Button(new Rect((Screen.width - 100) * 0.5f, Screen.height - 140, 100, 50), "Purchase"))
		{
			Debug.Log("Purchase");
			Together.Instance.User.UserAchievementManager.Purchase(m_Achievement.AchievementID, 	// achievementID
																   0,								// roomID
																   null,//m_Achievement.Properties,		// userAchievementProperties
																   false,							// useGameUserProfileProperties
																   onAchievementPurchased);			// callbackFunc
		}
	}	
	
	void onAchievementAwarded(TogetherCallback tcb)
	{
		if (tcb.Success)
			Application.LoadLevel ("AchievementsLobby");
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}

	void onAchievementPurchased(TogetherCallback tcb)
	{
		if (tcb.Success)
			Application.LoadLevel ("AchievementsLobby");
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
/*
	void onAchievementAction(TogetherCallback tcb)
	{
		if(tcb.Success)
			Helper.together.userAchievementManager.GetAll(onUserAchievementsReloaded);
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void onUserAchievementsReloaded(TogetherCallback tcb)
	{
		Application.LoadLevel("AchievementsLobby");
	}
*/
}
