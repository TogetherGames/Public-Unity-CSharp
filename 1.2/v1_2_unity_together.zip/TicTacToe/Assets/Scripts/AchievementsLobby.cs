using UnityEngine;
using System.Collections;
using PlaysTogether;

public class AchievementsLobby : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private bool m_bDisplay = false;
	private int textWidth = 500;
	private int buttonWidth = 400;
	private PlaysTogether.Achievement[] m_Achievements;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		Together.Instance.AchievementManager.GetAll(onAllAchievementsRetrieved);		// callbackFunc
	}
	
	void onAllAchievementsRetrieved(TogetherCallback tcb)
	{
		Debug.Log("onAllAchievementsRetrieved " + tcb);
		
		if(tcb.Success)
		{	
			m_bDisplay = true;
			
			int count = Together.Instance.AchievementManager.GetCount();
			Debug.Log("Achievement count " + count);
			if(count > 7)
				count = 7;

			m_Achievements = new PlaysTogether.Achievement[count];
			
			for (int i = 0; i < count; i++) 
				m_Achievements[i] = Together.Instance.AchievementManager.Get(i);
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		
		DisplayButtons();
	}
	
	void DisplayText()
	{
		//Create and set our labels
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, 15, textWidth, 100), "Achievements Lobby", m_TitleStyle);	
		
	}
	
	void DisplayButtons()
	{
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");
		
		//if( GUI.Button(new Rect((Screen.width - 200) * 0.5f, 200 + (60 * i), 200, 50), "Achievment1"))
		//	Application.LoadLevel("Achievement");
		
		if(m_bDisplay)
		{	
			for (int i = 0; i < m_Achievements.Length; i++) 
			{
				string display = "ID=" + m_Achievements[i].AchievementID + ", Name=" + m_Achievements[i].Name + ", Action=" + m_Achievements[i].ActionName;
				if( GUI.Button(new Rect((Screen.width - 400) * 0.5f, 200 + (60 * i), buttonWidth, 50), display))
				{
					Helper.UserData = m_Achievements[i];
					Application.LoadLevel("Achievement");
				}
			}
		}
	}
}
