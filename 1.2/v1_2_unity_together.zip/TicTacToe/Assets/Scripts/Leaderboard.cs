using UnityEngine;
using System;
using System.Collections;
using PlaysTogether;

public class Leaderboard : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private PlaysTogether.Leaderboard m_Leaderboard;
	
	// Use this for initialization
	void Start () 
	{
		m_Leaderboard = Helper.UserData as PlaysTogether.Leaderboard;
		
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;

		m_Leaderboard.GetDetails(false,						// friendsOnly
								 onGotLeaderboardDetails);	// callbackFunc
	}

	void onGotLeaderboardDetails(TogetherCallback tcb)
	{
		Debug.Log("onGotLeaderboardDetails " + tcb);
		if (tcb.Success)
		{	
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}

	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayLeaderboardInfo();
		DisplayLeaderboardUsers();
		DisplayButtons();
	}
	
	void DisplayLeaderboardInfo()
	{
		int labelY = 100;
		int labelYStep = 30;
		int winningScore = GetWinningScore();

		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 25, 300, 100), "Leaderboard", m_TitleStyle);
		
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "LeaderboardID = " + m_Leaderboard.LeaderboardID, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "CreatorUserID = " + m_Leaderboard.CreatorUserID, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100),"RoomID = " + m_Leaderboard.RoomID, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "SecondsSinceStart = " + m_Leaderboard.SecondsSinceStart, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "SecondsSinceFinish = " + m_Leaderboard.SecondsSinceFinish, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "MaxUsers = "+ m_Leaderboard.MaxUsers, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "TurnIndex = " + m_Leaderboard.TurnIndex, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "WinningUserID = " + m_Leaderboard.WinningUserID, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "WinningScore = " + winningScore, m_TextStyle);	
		labelY += labelYStep;
	}
	
	void DisplayLeaderboardUsers()
	{
		int labelY = 400;
		int labelYStep = 30;
		LeaderboardUser leaderboardUser;
		
		for (int i=0; i<m_Leaderboard.GetLeaderboardUserCount(); i++)
		{
			leaderboardUser = m_Leaderboard.GetLeaderboardUser(i);
			
			GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 50),
				leaderboardUser.Username + ", Score=" + leaderboardUser.Properties.GetEx("Score", "0"), m_TextStyle);	

			labelY += labelYStep;
		}
	}

	int GetWinningScore()
	{
		int winningScore = 0;

		if (m_Leaderboard.WinningUserID != 0)
		{
			LeaderboardUser leaderboardUser = m_Leaderboard.FindLeaderboardUserByUserID(m_Leaderboard.WinningUserID);
			if (leaderboardUser != null)
				winningScore = Convert.ToInt32(leaderboardUser.Properties.Get("Score"));	
		}		

		return winningScore;
	}

	void DisplayButtons()
	{
		//Create and set the buttons
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("LeaderboardsLobby");
	}	
}
