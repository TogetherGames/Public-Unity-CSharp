using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using PlaysTogether;

public class UserItem : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private int textWidth = 500;
	private PlaysTogether.UserItem m_UserItem;
	
	// Use this for initialization
	void Start () 
	{
		m_UserItem = Helper.UserData as PlaysTogether.UserItem;
		
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{
		int labelY = 65;
		int labelYStep = 30;

		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, 15, textWidth, 100), "User Item", m_TitleStyle);
		
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "UserItemID =" + m_UserItem.Item.ItemID, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Name = " + m_UserItem.Item.Name, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Description = "+ m_UserItem.Item.Description, m_TextStyle);	
		labelY += labelYStep;

		// Display all the UserItem properties.
		if (m_UserItem.Properties.Properties != null)
		{
			foreach (Property property in m_UserItem.Properties.Properties)
			{
				GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), property.Name + " = " + property.Value, m_TextStyle);
				labelY += labelYStep;
			}
		}
	}
	
	void DisplayButtons()
	{
		//Create and set the buttons
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("UserItemsLobby");
	
		if( GUI.Button(new Rect((Screen.width - 100) * 0.5f, Screen.height - 200, 100, 50), "Sell"))
		{
			Debug.Log("Sell");
			Together.Instance.User.UserItemManager.Sell(m_UserItem.UserItemID, onUserItemAction);
		}
		if( GUI.Button(new Rect((Screen.width - 100) * 0.5f, Screen.height - 140, 100, 50), "Delete"))
		{
			Debug.Log("Delete");
			Together.Instance.User.UserItemManager.Delete(m_UserItem.UserItemID, onUserItemAction);
		}
	}	
	
	void onUserItemAction(TogetherCallback tcb)
	{
		if (tcb.Success)
			Together.Instance.User.UserItemManager.GetAll(onUserItemManagerReloaded);
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void onUserItemManagerReloaded(TogetherCallback tcb)
	{
		if(!tcb.Success)
			Helper.Popup("Uh oh", tcb.Message, 0);
		
		Application.LoadLevel("UserItemsLobby");
	}
}
