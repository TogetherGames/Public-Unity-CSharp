using UnityEngine;
using System.Collections;
using PlaysTogether;

public class ChatRoom : MonoBehaviour
{
	private string m_input = "";
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private PlaysTogether.ChatRoom m_chatRoom;
	private string[] m_messages;
	private string[] m_userNames;
	
	// Use this for initialization
	void Start () 
	{
		m_chatRoom = Helper.UserData as PlaysTogether.ChatRoom;
		
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		m_messages = null;
		m_userNames = null;
		
		GetChatRoomDetails();
	}
	
	// Update is called once per frame
	void Update () 
	{
		if(Input.GetKey(KeyCode.Return) || Input.GetKey(KeyCode.KeypadEnter))
			SendTextMessage();
	}
	
	void SendTextMessage()
	{
		if(m_input != "")
		{
			Debug.Log("Display message " + m_input);
			m_chatRoom.CreateMessage(0, m_input, onMessageSent);
			m_input = "";
		}
	}
	
	void onMessageSent(TogetherCallback tcb)
	{
		Debug.Log("on message sent " + tcb);
		if (tcb.Success)
			GetChatRoomDetails();
		else 
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void GetChatRoomDetails()
	{
		Debug.Log ("Call GetChatRoomDetails");
		m_chatRoom.GetDetails( m_chatRoom.ChatRoomID, 0, onGotChatRoomDetails);
	}
	
	void onGotChatRoomDetails(TogetherCallback tcb)
	{
		Debug.Log("onGotChatRoom " + tcb);
		if (tcb.Success)
			UpdateText();
		else if (tcb.Status == "Deleted")
			GoToChatRoomLobby();
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void UpdateText()
	{
		//Update messages
		int count = m_chatRoom.ChatMessages.Count;
		m_messages = new string[count];
		
		for (int i = 0; i < count; i++)
		{
			m_messages[i] = BuildChatMessageLabel(m_chatRoom.ChatMessages[i]);
		}
		
		//Update names
		count = m_chatRoom.ChatRoomUsers.Count;
		m_userNames = new string[count];
		
		for (int i = 0; i < count; i++)
		{
			m_userNames[i] = m_chatRoom.ChatRoomUsers[i].Username;
		}
	}
	
	string BuildChatMessageLabel(PlaysTogether.ChatMessage chatMessage)
	{
		string messageLabel = chatMessage.Username + " - " + chatMessage.Message;
		if (chatMessage.Read)
			messageLabel = "* " + messageLabel;
		return messageLabel;
	}
	
	
	void GoToChatRoomLobby()
	{
		Application.LoadLevel("ChatRoomLobby");
	}
	
	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{
		//input field see if they enter anything for a message
		m_input = GUI.TextField(new Rect(10, 520, 300, 25), m_input);
		
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 15, 300, 100), "Chat Room", m_TitleStyle);
		GUI.Label(new Rect((Screen.width - 325), 75, 300, 100), "Users", m_TitleStyle);
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 200, 300, 100), "Message", m_TitleStyle);
		
		//The Messages
		if (m_messages != null)
		{
			for (int i = 0; i < m_messages.Length; i++)
			{
				GUI.Label(new Rect((Screen.width - 300) * 0.5f, 250 + (25 * i), 300, 40), m_messages[i], m_TextStyle);
			}
		}
		
		//The Users
		if (m_userNames != null)
		{
			for (int i = 0; i < m_userNames.Length	; i++)
			{
				GUI.Label(new Rect((Screen.width - 325), 125 + (25 * i), 300, 40), m_userNames[i], m_TextStyle);
			}
		}
		
	}
	
	void DisplayButtons()
	{
		//Create and set the buttons
		if( GUI.Button(new Rect(10, 50, 100, 40), "Back"))
			GoToChatRoomLobby();
		
		if( GUI.Button(new Rect(10, 120, 180, 40), "Join Room"))
		{
			Debug.Log("Join Room");
			m_chatRoom.Join(onMessageAction);	
		}
		if( GUI.Button(new Rect(10, 175, 180, 40), "Leave Room"))
		{
			Debug.Log("Leave Room");
			//Leave the current room
			m_chatRoom.Leave(onDeletedOrLeft);
		}
		if( GUI.Button(new Rect(10, 230, 180, 40), "Delete Room"))
		{
			Debug.Log("Delete Room");
			Together.Instance.ChatRoomManager.Delete(m_chatRoom.ChatRoomID, onDeletedOrLeft);
		}
		if( GUI.Button(new Rect(10, 285, 180, 40), "Delete Last Message"))
		{
			Debug.Log("Delete Last Message");
			if (m_chatRoom.GetChatMessageCount() > 0)
			{	
				ChatMessage chatMessage = m_chatRoom.GetChatMessage(m_chatRoom.GetChatMessageCount()-1);
				m_chatRoom.DeleteMessage(chatMessage.ChatMessageID, onMessageAction);
			}
		}
		if( GUI.Button(new Rect(10, 340, 180, 40), "Mark Top Mesage As Read"))
		{
			Debug.Log("Mark Top Mesage As Read");
			if (m_chatRoom.GetChatMessageCount() > 0)
			{	
				ChatMessage markMessage = m_chatRoom.GetChatMessage(m_chatRoom.GetChatMessageCount()-1);
				m_chatRoom.MarkMessageAsRead(markMessage.ChatMessageID, onMessageAction);
			}
		}
		if( GUI.Button(new Rect(10, 395, 180, 40), "Invite Friend"))
		{
			OnInviteFriendButtonClicked();
		}
		if( GUI.Button(new Rect(10, 450, 180, 40), "Send Message"))
		{
			SendTextMessage();
		}
		
	}
	
	void OnInviteFriendButtonClicked()
	{
		Debug.Log ("OnInviteFriendButtonClicked()");
		
		FriendLobby.PreviousScreen = "ChatRoom";
		Application.LoadLevel("FriendLobby");
	}

	void onDeletedOrLeft(TogetherCallback tcb)
	{
		GoToChatRoomLobby();
	}
	
	void onMessageAction(TogetherCallback tcb)
	{
		if (tcb.Success)
			GetChatRoomDetails();
	}
}
