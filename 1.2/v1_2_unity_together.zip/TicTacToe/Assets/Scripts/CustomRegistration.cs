using UnityEngine;
using System.Collections;
using PlaysTogether;

public class CustomRegistration : MonoBehaviour
{
	private string m_inEmail = "";
	private string m_inPassword = "";
	private string m_inVerifyPassword = "";
	private string m_inName = "";
	
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;

	}
	
	// Update is called once per frame
	void Update () 
	{
	}

	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{
		int labelY = 150;
		int labelYStep = 40;

		GUI.Label(new Rect((Screen.width - 500) * 0.5f, 15, 500, 50), "Custom Registration", m_TitleStyle);
		
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 40), "Email:", m_TextStyle);
		labelY += labelYStep - 15;
		m_inEmail = GUI.TextField(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 25), m_inEmail);
		labelY += labelYStep;

		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 40), "Password:", m_TextStyle);
		labelY += labelYStep - 15;
		m_inPassword = GUI.TextField(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 25), m_inPassword);
		labelY += labelYStep;

		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 40), "Verify Password:", m_TextStyle);
		labelY += labelYStep - 15;
		m_inVerifyPassword = GUI.TextField(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 25), m_inVerifyPassword);
		labelY += labelYStep;

		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 40), "Name:", m_TextStyle);
		labelY += labelYStep - 15;
		m_inName = GUI.TextField(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 25), m_inName);
		labelY += labelYStep;
	}
	
	void DisplayButtons()
	{
		//Create and set the buttons
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("Register");
		
		if( GUI.Button(new Rect((Screen.width - 180) * 0.5f, Screen.height - 200, 180, 50), "Register"))
		{
			if(m_inEmail == "" || m_inName == "" || m_inPassword == "")
			{
				Helper.Popup("Uh oh", "All fields are required!", 0);
			}
			else
			{
				if (m_inPassword != m_inVerifyPassword)
				{
					Helper.Popup("Uh oh", "You must verify the password!", 0);
				}
				else
				{
					Debug.Log("Register custom user");
					Together.Instance.RegisterCustom(m_inEmail, 			// email
													 m_inPassword,			// password
													 m_inName,				// name
													 onCustomRegistered);	// callbackFunc
				}
			}
		}	
	}

	void onCustomRegistered(TogetherCallback tcb)
	{
		if(!tcb.Success)
			Helper.Popup("Uh oh", tcb.Message, 0);
		
		Application.LoadLevel("Register");
	}
}
	
