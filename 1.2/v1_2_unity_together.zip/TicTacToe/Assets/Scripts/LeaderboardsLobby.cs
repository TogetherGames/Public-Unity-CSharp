using UnityEngine;
using System.Collections;
using PlaysTogether;

public class LeaderboardsLobby : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private User m_User;
	private bool m_bDisplay = false;
	private int textWidth = 500;
	private int buttonWidth = 400;
			
	private PlaysTogether.Leaderboard[] m_leaderboards;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		
		m_User = Together.Instance.User;
		
		Debug.Log("Together.Instance.LeaderboardManager.GetAll(" + m_User.UserID + ")");
		
		Together.Instance.LeaderboardManager.GetAll(m_User.UserID, onGotAllLeaderboards);	// callbackFunc
	}
	void onGotAllLeaderboards(TogetherCallback tcb)
	{
		Debug.Log("onGotAllLeaderboards " + tcb);
		if(tcb.Success)
		{	
			m_bDisplay = true;
			int count = Together.Instance.LeaderboardManager.GetCount();
			Debug.Log("leaderboards count " + count);
			if (count > 7)
				count = 7;

			m_leaderboards = new PlaysTogether.Leaderboard[count];
			
			for (int i = 0; i < count; i++) 
				m_leaderboards[i] = Together.Instance.LeaderboardManager.Get(i);
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		
		DisplayButtons();
	}
	
	void DisplayText()
	{
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 500) * 0.5f, 15, textWidth, 100), "Leaderboards Lobby", m_TitleStyle);
		GUI.Label(new Rect((Screen.width - 500) * 0.5f, 65, textWidth, 100), "UserID = " + m_User.UserID, m_TextStyle);	
		GUI.Label(new Rect((Screen.width - 500) * 0.5f, 90, textWidth, 100), "Username = " + m_User.Username, m_TextStyle);	
		GUI.Label(new Rect((Screen.width - 500) * 0.5f, 115, textWidth, 100), "Name = " + m_User.Name, m_TextStyle);	
	}
	
	void DisplayButtons()
	{
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");	
		
		//if( GUI.Button(new Rect((Screen.width - 200) * 0.5f, (Screen.height - 50 ) * 0.5f, 200, 50), "Leaderboard1"))
		//	Application.LoadLevel("Leaderboard");
		
		PlaysTogether.Leaderboard leaderboard;
		int winningScore = 0;

		if (m_bDisplay)
		{	
			for (int i = 0; i < m_leaderboards.Length; i++) 
			{
				leaderboard = m_leaderboards[i];
				winningScore = GetLeaderboardWinningScore(leaderboard);

				string display =  "ID=" + leaderboard.LeaderboardID + ", WinUser=" + leaderboard.WinningUserID + ", WinScore=" + winningScore;
				if( GUI.Button(new Rect((Screen.width - 400) * 0.5f, 200 + (60 * i),  buttonWidth, 50), display))
				{	
					//Save the data for the leaderboard scene
					Helper.UserData = m_leaderboards[i];
					Application.LoadLevel("Leaderboard");
				}
			}
		}
	}
	
	int GetLeaderboardWinningScore(PlaysTogether.Leaderboard leaderboard)
	{
		int winningScore = 0;

		if (leaderboard.WinningUserID != 0)
		{
			PlaysTogether.LeaderboardUser leaderboardUser = leaderboard.FindLeaderboardUserByUserID(leaderboard.WinningUserID);
			if (leaderboardUser != null)
			{
				PlaysTogether.Property scoreProperty = leaderboardUser.Properties.Get ("Score");
				if (scoreProperty != null)
					winningScore = int.Parse (scoreProperty.Value);	
			}
		}

		return winningScore;
	}
	
	
}
