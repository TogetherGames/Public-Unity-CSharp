using UnityEngine;
using System.Collections;
using PlaysTogether;

public class GameLobby : MonoBehaviour
{
	private const int REFRESH_TIME = 7;
	private int m_ActiveGameMask;
	private float waitTime = 0;
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private User m_User;
	private PlaysTogether.GameInstance[] m_games;
	private string[] m_displayStrings;
	private bool m_bDisplayGames = false;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		m_User = Together.Instance.User;

		//List of Active Games
		m_ActiveGameMask = GameStateMask.IN_PROGRESS | GameStateMask.POSSIBLE_REMATCH | GameStateMask.WAITING_FOR_PLAYERS;
		
		Together.Instance.GameInstanceManager.GetAll(0, m_ActiveGameMask, 10, true, false, null, null, onGotAllGames);
	}
	
	// Update is called once per frame
	void Update () 
	{
		waitTime += Time.deltaTime;
		//Debug.Log("wait time " + waitTime);
		if( waitTime >= REFRESH_TIME)
		{
			RefreshLobby();
			waitTime = 0;
		}
	}
	
	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{	
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 15, 300, 100), "Game Lobby", m_TitleStyle);	
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 65, 300, 100), "UserID = " + m_User.UserID, m_TextStyle);	
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 90, 300, 100), "UserName = " + m_User.Username, m_TextStyle);	
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 115, 300, 100), "Name = " + m_User.Name, m_TextStyle);
	}
	
	void DisplayButtons()
	{
		//Create and set all our buttons
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");

		if(m_bDisplayGames)
		{
			for (int i = 0; i < m_games.Length; i++) 
			{
				if( GUI.Button(new Rect((Screen.width - 400) * 0.5f, 355 + (60 * i), 400, 50), m_displayStrings[i]))
					OnGameClicked(m_games[i]);
			}
		}
		
		//TODO need to grab the specific game Properties
		if( GUI.Button(new Rect((Screen.width - 200) * 0.5f, 190, 200, 50), "Create Game"))
			OnCreateButtonClicked ();	
		if( GUI.Button(new Rect((Screen.width - 200) * 0.5f, 250, 200, 50), "Join Random Game"))
			OnJoinRandomButtonClicked ();	
	}
	
	void OnCreateButtonClicked()
	{
		PropertyCollection propertyCollection = new PropertyCollection();
		propertyCollection.Name = "a";
		propertyCollection.Set ("Data", "_________");

		Together.Instance.GameInstanceManager.Create("",						//  gameInstanceType
													 0,							//  roomID
													 2, 						//  maxUsers
													 false,						//  passTurn
													 propertyCollection,		//  gameInstanceProperties,
													 null,						//  gameInstanceUserProperties
													 onGameInstanceCreated);	//  callbackFunc
	}
	void onGameInstanceCreated(TogetherCallback tcb) 
	{
		if (tcb.Success)
		{
			// Refresh the list of GameInstances during next Update() call.
			waitTime = REFRESH_TIME;
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}

	void OnJoinRandomButtonClicked()
	{
		Together.Instance.GameInstanceManager.JoinRandom("",					//  gameInstanceType
														 null,					//  gameInstanceUserProperties
														 onRandomGameJoined);	//  callbackFunc
	}
	void onRandomGameJoined(TogetherCallback tcb) 
	{
		Debug.Log("onRandomGameJoined " + tcb);
		
		if (tcb.Success)
		{
			// Refresh the list of GameInstances during next Update() call.
			waitTime = REFRESH_TIME;
			Application.LoadLevel("GameInstance");
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}	

	void RefreshLobby()
	{
		Debug.Log("refresh lobby");
		int gameStateMask = GameStateMask.IN_PROGRESS | GameStateMask.POSSIBLE_REMATCH | GameStateMask.WAITING_FOR_PLAYERS;
		Together.Instance.GameInstanceManager.GetAll(0,					//  userID
													 gameStateMask,		//  stateMasks
													 10,				//  maxCount
													 true,				//  getGameInstanceProperties
													 false,				//  friendsOnly,
													 null,
													 null,
													 onGotAllGames);	//  callbackFunc
	
		//check notifications
//		Together.Instance.UserNotificationManager.GetAll(false, onRecievedNotification);
	}
	
	void onRecievedNotification(TogetherCallback tcb)
	{
		Debug.Log("On Recieved notification");
		if(tcb.Success)
		{
			int count  = Together.Instance.UserNotificationManager.GetCount();
			for (int i = 0; i < count; i++) 
			{
				UserNotification userNotification = Together.Instance.UserNotificationManager.Get(i);
				Together.Instance.UserNotificationManager.Process( userNotification.UserNotificationID, true, onNotificationSeen);
				Helper.Popup("HEY", userNotification.Message, 0);
			}
		}
		//else
		//	Helper.Popup("Uh oh", tcb.Message, 0);
	}

	void onNotificationSeen(TogetherCallback tcb)
	{
		Debug.Log("onNotificationSeen");
		if(!tcb.Success)
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void onGotAllGames(TogetherCallback tcb)
	{
		Debug.Log("onGotAllGames ");
		if(tcb.Success)
		{			
			int count = Together.Instance.GameInstanceManager.GetCount();
			if (count > 7)
				count = 7;
			
			m_games = new PlaysTogether.GameInstance[count];
			m_displayStrings = new string[count];

			for (int i = 0; i < count; i++) 
			{
				PlaysTogether.GameInstance gameInstance = Together.Instance.GameInstanceManager.Get(i);
				m_games[i] =  gameInstance;
					
				m_displayStrings[i] = BuildGameButtonLabel(gameInstance);
			}
			
			m_bDisplayGames = true;
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	string BuildGameButtonLabel(PlaysTogether.GameInstance gameInstance)
	{
		string buttonLabel = "ID=" + gameInstance.GameInstanceID +
			", Users=" + gameInstance.UserCount + "/" + gameInstance.MaxUsers;
		
		if (gameInstance.GameInstanceID != gameInstance.GameInstanceDuelID)
			buttonLabel += ", Duel";
		
		if (gameInstance.State == PlaysTogether.GameStateMask.WAITING_FOR_PLAYERS)
			buttonLabel += ", Waiting For Users";
		else if (gameInstance.State == PlaysTogether.GameStateMask.IN_PROGRESS)
			buttonLabel += ", In Progress";
		else if (gameInstance.State == PlaysTogether.GameStateMask.FINISHED)
			buttonLabel += ", Finished";
		else if (gameInstance.State == PlaysTogether.GameStateMask.POSSIBLE_REMATCH)
			buttonLabel += ", Possible Rematch";
		
		return buttonLabel;
	}
	
	void OnGameClicked(PlaysTogether.GameInstance gi)
	{
		Debug.Log("state of game obect " + gi.State);
		
		//stop the game time so a refresh doesnt hapen while we enter a game
		waitTime = -5;
		
		bool showGame = false;

		switch (gi.State) 
		{
		case GameStateMask.WAITING_FOR_PLAYERS:
//			Debug.Log("Waiting");
//			Helper.Popup("hmm", "Still Waiting on players", 0);
			showGame = true;
			break;
		case GameStateMask.FINISHED:
			Debug.Log("Uh oh, Game finished");
			Helper.Popup("hmm", "Game is finished", 0);
			break;
		case GameStateMask.POSSIBLE_REMATCH:
			Debug.Log("Rematch?");
			Helper.Popup("hmm", "Rematch!", 0);
			break;
		default:
			//Store our game for when we load the gameInstance
//			Helper.UserData = gi;
//			Application.LoadLevel("GameInstance");
			showGame = true;
			break;
		}
		
		if (showGame)
		{
			//Store our game for when we load the gameInstance
			Helper.UserData = gi;
			
			Together.Instance.GameInstanceManager.Join(gi.GameInstanceID,
														 null,					//  gameInstanceUserProperties
														 onRandomGameJoined);	//  
		}
	}
	
}
