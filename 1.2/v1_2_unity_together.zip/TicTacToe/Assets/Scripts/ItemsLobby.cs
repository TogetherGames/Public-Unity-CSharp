using UnityEngine;
using System.Collections;
using PlaysTogether;

public class ItemsLobby : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private bool m_bDisplay = false;
	private int textWidth = 500;
	private int buttonWidth = 400;
	private PlaysTogether.Item[] m_items;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		Together.Instance.ItemManager.GetAll(onGotAllItems);			// callbackFunc
		
	}
	
	void onGotAllItems(TogetherCallback tcb)
	{
		Debug.Log("onGotAllItems " + tcb);
		if (tcb.Success)
		{	
			m_bDisplay = true;
			
			int count = Together.Instance.ItemManager.GetCount();
			Debug.Log("items count " + count);
			if (count > 7)
				count = 7;

			m_items = new PlaysTogether.Item[count];
			
			for (int i = 0; i < count; i++) 
				m_items[i] = Together.Instance.ItemManager.Get(i);
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		
		DisplayButtons();
	}
	
	void DisplayText()
	{
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, 15, textWidth, 100), "Items Lobby", m_TitleStyle);	
		
	}
	
	void DisplayButtons()
	{
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");
		
		//if( GUI.Button(new Rect((Screen.width - 200) * 0.5f, (Screen.height - 50 ) * 0.5f, 200, 50), "Item1"))
		//	Application.LoadLevel("Item");
				
		if(m_bDisplay)
		{	
			for (int i = 0; i < m_items.Length; i++) 
			{
				string display = "ID=" + m_items[i].ItemID + ", Name=" + m_items[i].Name;
				if( GUI.Button(new Rect((Screen.width - buttonWidth) * 0.5f, 200 + (60 * i), buttonWidth, 50), display))
				{	
					Helper.UserData = m_items[i];
					Application.LoadLevel("Item");
				}
			}
		}
	}
}
