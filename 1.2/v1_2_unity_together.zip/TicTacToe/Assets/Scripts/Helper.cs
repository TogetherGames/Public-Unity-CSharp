using UnityEngine;
using System.Collections;
using PlaysTogether;

public class Helper  
{
	
	//Used when passing data between scenes
	public static object UserData;
	
	public static void Popup(string title, string message,
		int winID, Popup.PopupButtonClickedDelegate callbackFunction=null)
	{
		GameObject p = 	GameObject.Instantiate( Resources.Load("Popup") as GameObject) as GameObject;
		Popup pop = p.GetComponent<Popup>();
		pop.Initialize(title, message, "Ok", "", winID, callbackFunction);
	}

	public static void Popup(string title, string message, string button1Text,
		int winID, Popup.PopupButtonClickedDelegate callbackFunction=null)
	{
		GameObject p = 	GameObject.Instantiate( Resources.Load("Popup") as GameObject) as GameObject;
		Popup pop = p.GetComponent<Popup>();
		pop.Initialize(title, message, button1Text, "", winID, callbackFunction);
	}

	public static void Popup(string title, string message, string button1Text, string button2Text,
		int winID, Popup.PopupButtonClickedDelegate callbackFunction=null)
	{
		GameObject p = 	GameObject.Instantiate( Resources.Load("Popup") as GameObject) as GameObject;
		Popup pop = p.GetComponent<Popup>();
		pop.Initialize(title, message, button1Text, button2Text, winID, callbackFunction);
	}
}
