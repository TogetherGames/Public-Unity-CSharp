using UnityEngine;
using System.Collections;
using PlaysTogether;
using PlaysTogether.Social;
using PlaysTogether.Social.FBObjects;

public class FacebookRegistration : MonoBehaviour
{
	private string m_FacebookFacebookID = "";
	private string m_FacebookName = "";
	private string m_FacebookFirstName = "";
	private string m_FacebookLastName = "";
	private string m_FacebookLink = "";
	private string m_FacebookUsername = "";
	private string m_FacebookGender = "";
	private string m_FacebookLocale = "";

	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	
	private bool m_ShowControls = true;


	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		CacheFacebookUserMembers();
		Together.Instance.Social.Facebook.Initialize("380670285349853");
	}
	
	void CacheFacebookUserMembers()
	{
		PlaysTogether.FacebookUser facebookUser = Together.Instance.User.GetFacebookUser();
		
		m_FacebookFacebookID 	= facebookUser.FacebookID;
		m_FacebookName 			= facebookUser.Name;
		m_FacebookFirstName 	= facebookUser.FirstName;
		m_FacebookLastName 		= facebookUser.LastName;
		m_FacebookLink 			= facebookUser.Link;
		m_FacebookUsername 		= facebookUser.Username;
		m_FacebookGender 		= facebookUser.Gender;
		m_FacebookLocale 		= facebookUser.Locale;
	}

	// Update is called once per frame
	void Update () 
	{
	}

	void OnGUI()
	{
		if (m_ShowControls)
		{
			DisplayText();
			DisplayButtons();
		}
	}
	
	void DisplayText()
	{
		int labelWidth = 500;

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 15, labelWidth, 100), "Facebook Registration", m_TitleStyle);
		

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 150, labelWidth, 100), "FacebookID:  " + m_FacebookFacebookID, m_TextStyle);

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 180, labelWidth, 100), "Name:  " + m_FacebookName, m_TextStyle);

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 210, labelWidth, 100), "First Name:  " + m_FacebookFirstName, m_TextStyle);

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 240, labelWidth, 100), "Last Name:  " + m_FacebookLastName, m_TextStyle);

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 270, labelWidth, 100), "Link:  " + m_FacebookLink, m_TextStyle);
		
		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 300, labelWidth, 100), "Username:  " + m_FacebookUsername, m_TextStyle);

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 330, labelWidth, 100), "Gender:  " + m_FacebookGender, m_TextStyle);

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 360, labelWidth, 100), "Locale:  " + m_FacebookLocale, m_TextStyle);
		
		int friendCount = Together.Instance.Social.Facebook.GetFacebookFriendCount();
		ExternalFriend facebookFriend;
		string friendLabel = "";

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 390, labelWidth, 100), "FriendCount:  " + friendCount, m_TextStyle);
	
		if (friendCount > 5)
			friendCount = 5;
			
		for (int a=0; a<friendCount; a++)
		{
			facebookFriend = Together.Instance.Social.Facebook.GetFacebookFriend(a);
			
			friendLabel = "Type=" + facebookFriend.FriendType + ", ID=" + facebookFriend.FriendID + ", Name=" + facebookFriend.Name;
					
			GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, 420+(a*25), labelWidth, 100), friendLabel, m_TextStyle);
		}
	}
	
	void DisplayButtons()
	{
		//Create and set the buttons
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("Register");
		
		if( GUI.Button(new Rect((Screen.width - 180) * 0.5f, Screen.height - 160, 180, 50), "Log into Facebook"))
		{
			OnLogIntoFacebookButtonClicked();
		}
		

/*
		if (GUI.Button(new Rect((Screen.width - 180) * 0.5f, Screen.height - 300, 180, 50), "Send"))
		{
			if(m_inName != "" && m_inLastName != "" && m_inEmail != "" && m_inUsername != "" && m_inGender != "") 
			{
				Debug.Log("RegisterFacebook");
				Together.Instance.RegisterFacebook("0", "Test", m_inName, m_inLastName, m_inEmail, m_inUsername, m_inGender, "En_us", onFacebookRegistered); 
				//m_inName = ""; m_inLastName = ""; m_inEmail = ""; m_inUsername = ""; m_inGender = "";
			}
			else
				Helper.Popup("Uh oh","All fields are required!", 0);
		}
*/
	}
	
	void OnLogIntoFacebookButtonClicked()
	{
		m_ShowControls = false;
		TogetherFacebook.Instance.Login(onFacebookRegistered);
	}
		
	void onFacebookRegistered(TogetherCallback tcb)
	{
		Debug.Log("FacebookRegistration.onFacebookRegistered()");
		Debug.Log("AccessToken=" + Together.Instance.Social.Facebook.AccessToken);
		Debug.Log("FriendCount=" + Together.Instance.Social.Facebook.GetFacebookFriendCount());
		
		m_ShowControls = true;

		if (!tcb.Success)
		{
			Helper.Popup("Uh oh", tcb.Message, 0);
			Debug.Log(tcb.Message);
		}
		else
		{
			Debug.Log("Got my Facebook account info.");
			Debug.Log("   tcb.Data = " + tcb.Data);	
			fboMe me = Together.Instance.Social.Facebook.Me;// (fboMe)tcb.Data;
			m_FacebookFacebookID 	= me.id;
			m_FacebookName 			= me.name;
			m_FacebookFirstName 	= me.first_name;
			m_FacebookLastName 		= me.last_name;
			m_FacebookLink 			= me.link;
			m_FacebookUsername 		= me.username;
			m_FacebookGender 		= me.gender;
			m_FacebookLocale 		= me.locale;

//   ResponseBody = {"id":"100001324882689","name":"Chris Nagle","first_name":"Chris","last_name":"Nagle","link":"http:\/\/www.facebook.com\/chris.nagle.948","username":"chris.nagle.948","hometown":{"id":"108045919230286","name":"Grant, Florida"},"location":{"id":"109407902410575","name":"Oviedo, Florida"},"work":[{"employer":{"id":"148124528537712","name":"Contractor"},"start_date":"0000-00","end_date":"0000-00"},{"employer":{"id":"137995002899694","name":"ZeeGee Games"},"with":[{"id":"644890279","name":"Laura Hellinger"}],"from":{"id":"644890279","name":"Laura Hellinger"}}],"education":[{"school":{"id":"113588468653659","name":"Palm Bay High School"},"type":"High School"},{"school":{"id":"110540222300476","name":"Florida State"},"type":"College"}],"gender":"male","timezone":-4,"locale":"en_US","verified":true,"updated_time":"2012-11-29T19:23:13+0000"}
/*
			// Register the Together User with Facebook.
			Together.Instance.RegisterFacebook(m_FacebookFacebookID,		// facebookID
											   m_FacebookName,				// fbname
											   m_FacebookFirstName,			// first_name
											   m_FacebookLastName,			// last_name
											   m_FacebookLink,				// link
											   m_FacebookUsername,			// username
											   m_FacebookGender,			// gender
											   m_FacebookLocale,			// locale
											   onRegisteredWithFacebook);	// callbackFunc
*/
			Together.Instance.User.Dump();

			Together.Instance.RegisterFacebook(me.id,						// facebookID
											   me.name,						// fbname
											   me.first_name,				// first_name
											   me.last_name,				// last_name
											   me.link,						// link
											   me.username,					// username
											   me.gender,					// gender
											   me.locale,					// locale
											   onRegisteredWithFacebook);	// callbackFunc
			 
//			Application.LoadLevel("Register");
		}
	}

	void onRegisteredWithFacebook(TogetherCallback tcb)
	{
		Debug.Log("FacebookRegistration.onRegisteredWithFacebook()");
		
		CacheFacebookUserMembers();
		
		
		Debug.Log("   Syncing friends.");
		Together.Instance.FriendUserManager.SyncFriends("FB", Together.Instance.Social.Facebook.Friends.ToArray(), onSyncFriends);
	}
	
	void onSyncFriends(TogetherCallback tcb)
	{
		Debug.Log("FacebookRegistration.onSyncFriends()");

		if (!tcb.Success)
		{
		
		
		}
	}
	
}
