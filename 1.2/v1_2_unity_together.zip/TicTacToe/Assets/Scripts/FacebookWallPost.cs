using UnityEngine;
using System.Collections;
using PlaysTogether;

public class FacebookWallPost : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	
	public Texture FacebookTexture = null;

	
	private string m_WallPostName 			= "Unity: PlaysTogether";
	private string m_WallPostDescription 	= "Just played a game.";
	private string m_WallPostMessage 		= "La de dah.  I just did something in a game.";
	private string m_WallPostLink 			= "http://www.gamesbycandlelight.com";
	private string m_WallPostCaption 		= "Caption Text";


	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
	}

	// Update is called once per frame
	void Update() 
	{

	}

	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{	
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 600) * 0.5f, 15, 600, 50), "Facebook Wall Post", m_TitleStyle);	
		
		GUI.DrawTexture(new Rect(Screen.width - 148, 20, 128, 128), FacebookTexture, ScaleMode.ScaleToFit, true);


		GUI.Label(new Rect((Screen.width - 600) * 0.5f, 120, 600, 50), m_WallPostName, m_TextStyle);

		GUI.Label(new Rect((Screen.width - 600) * 0.5f, 150, 600, 50), m_WallPostDescription, m_TextStyle);

		GUI.Label(new Rect((Screen.width - 600) * 0.5f, 180, 600, 50), m_WallPostMessage, m_TextStyle);

		GUI.Label(new Rect((Screen.width - 600) * 0.5f, 210, 600, 50), m_WallPostLink, m_TextStyle);

		GUI.Label(new Rect((Screen.width - 600) * 0.5f, 240, 600, 50), m_WallPostCaption, m_TextStyle);
	}
	
	void DisplayButtons()
	{
		//Create and set all our buttons
		if (GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");

		if (GUI.Button(new Rect((Screen.width - 200) * 0.5f, 340, 200, 50), "Submit"))
			OnSubmitButtonClicked();
	}
	
	void OnSubmitButtonClicked()
	{
		Debug.Log("FacebookWallPost.OnSubmitButtonClicked()");
		TogetherFacebook.Instance.SendPost("Another test", "This is another test", "I like testing!", "", "Caption!", onFinishedPost);
	}
	
	public void onFinishedPost(TogetherCallback e)
	{
		Debug.Log("Finished Post!");
		Debug.Log("e.Success=" + e.Success);
		Debug.Log("e.Status=" + e.Status);
		Debug.Log("e.Message=" + e.Message);
	}
}
