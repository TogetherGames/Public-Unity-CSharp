using UnityEngine;
using System.Collections;

public class Register : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		
		DisplayButtons();
	}
	
	void DisplayText()
	{
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 15,300,100), "Register User", m_TitleStyle);	
	}
	
	void DisplayButtons()
	{
		int buttonWidth = 200;

		//Create and set the buttons
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");

		if( GUI.Button(new Rect((Screen.width-buttonWidth) * 0.5f, 160, buttonWidth, 50), "Facebook"))
			Application.LoadLevel("FacebookRegistration");
		if( GUI.Button(new Rect((Screen.width-buttonWidth) * 0.5f, 220, buttonWidth, 50), "Custom"))
			Application.LoadLevel("CustomRegistration");
	}
}
