using UnityEngine;
using System.Collections;
using PlaysTogether;

public class UserAchievementsLobby : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private bool m_bDisplay = false;
	private int textWidth = 500;
	private int buttonWidth = 400;
	private PlaysTogether.UserAchievement[] m_UserAchievements;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		Together.Instance.User.UserAchievementManager.GetAll(onAllUserAchievementsRetrieved);		// callbackFunc
	}
	
	void onAllUserAchievementsRetrieved(TogetherCallback tcb)
	{
		Debug.Log("onAllUserAchievementsRetrieved " + tcb);
		if(tcb.Success)
		{	
			m_bDisplay = true;
			
			int count = Together.Instance.User.UserAchievementManager.GetCount();
			Debug.Log("user achievement count " + count);
			if(count > 7)
				count = 7;

			m_UserAchievements = new PlaysTogether.UserAchievement[count];
			
			for (int i = 0; i < count; i++) 
				m_UserAchievements[i] = Together.Instance.User.UserAchievementManager.Get(i);
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 450) * 0.5f, 15, textWidth, 100), "User Achievements Lobby", m_TitleStyle);	
		
	}
	
	void DisplayButtons()
	{
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");
		
		//if( GUI.Button(new Rect((Screen.width - 200) * 0.5f, 200, 200, 50), "UserAchievement1"))
		//	Application.LoadLevel("UserAchievement");
				
		if(m_bDisplay)
		{	
			for (int i = 0; i < m_UserAchievements.Length; i++) 
			{
				string display = "ID=" + m_UserAchievements[i].UserAchievementID +
							", Name=" + m_UserAchievements[i].Achievement.Name + ", " + m_UserAchievements[i].RequiredCount + 
							"/" + m_UserAchievements[i].Achievement.RequiredCount +
							", Compl=" + m_UserAchievements[i].Completed.ToString();
				if( GUI.Button(new Rect((Screen.width - 400) * 0.5f, 200 + (60 * i), buttonWidth, 50), display))
				{	
					Helper.UserData = m_UserAchievements[i];
					Application.LoadLevel("UserAchievement");
				}
			}
		}
		
	}
}
