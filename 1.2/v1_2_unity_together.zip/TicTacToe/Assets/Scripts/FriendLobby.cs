using UnityEngine;
using System.Collections;
using PlaysTogether;

public class FriendLobby : MonoBehaviour
{
	public static string PreviousScreen = "";
	
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;

	
	public Texture FacebookTexture = null;
	
	private PlaysTogether.GameInstance m_GameInstance = null;
	private PlaysTogether.ChatRoom m_ChatRoom = null;

	private PlaysTogether.FriendUser m_TogetherFriend = null;
	private PlaysTogether.ExternalFriend m_FacebookFriend = null;

		
		
		
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;

		Together.Instance.FriendUserManager.GetAll(onGotTogetherFriends);
	}
	
	void onGotTogetherFriends(TogetherCallback tcb)
	{

	}

	// Update is called once per frame
	void Update () 
	{

	}
	
	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{	
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 600) * 0.5f, 15, 600, 50), "Select Friend to Invite to " + FriendLobby.PreviousScreen, m_TitleStyle);	
		
		GUI.DrawTexture(new Rect(Screen.width - 148, Screen.height - 148, 128, 128), FacebookTexture, ScaleMode.ScaleToFit, true);

	
		int labelWidth = 400;
		int i;
		PlaysTogether.FriendUser togetherFriend;
		PlaysTogether.ExternalFriend facebookFriend;
		int labelY = 80;
		string buttonLabel = "";

		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, labelY, labelWidth, 50), "Together Friends", m_TextStyle);	
		labelY += 30;

		for (i=0; i<Together.Instance.FriendUserManager.GetCount(); i++)
		{
			togetherFriend = Together.Instance.FriendUserManager.Get(i);	

			buttonLabel = "UserID=" + togetherFriend.UserID + ", Name=" + togetherFriend.Name;
				
			if (GUI.Button(new Rect((Screen.width - labelWidth) * 0.5f, labelY, labelWidth, 50), buttonLabel))
				OnTogetherFriendButtonClicked(togetherFriend);

			labelY += 30;
		}

		buttonLabel = "UserID=123456, Name=user_123456";
		if (GUI.Button(new Rect((Screen.width - labelWidth) * 0.5f, labelY, labelWidth, 50), buttonLabel))
			OnTogetherFriendButtonClicked(null);
		labelY += 30;

		labelY += 30;
		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, labelY, labelWidth, 50), "-------------------------------------", m_TextStyle);
		labelY += 30;
		
		GUI.Label(new Rect((Screen.width - labelWidth) * 0.5f, labelY, labelWidth, 50), "Facebook Friends", m_TextStyle);
		labelY += 30;
		
		for (i=0; i < Together.Instance.Social.Facebook.GetFacebookFriendCount(); i++)
		{
			facebookFriend = Together.Instance.Social.Facebook.GetFacebookFriend(i);

			if (GUI.Button(new Rect(260, labelY, 300, 50), "UserID=" + facebookFriend.FriendID + ", Name=" + facebookFriend.Name))
				OnFacebookFriendButtonClicked(facebookFriend);

			labelY += 35;
		}
	}
	
	void DisplayButtons()
	{
		//Create and set all our buttons
		if (GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			OnBackButtonClicked();
	}

	void OnBackButtonClicked()
	{
		Application.LoadLevel(FriendLobby.PreviousScreen);
	}

	void OnTogetherFriendButtonClicked(PlaysTogether.FriendUser togetherFriend)
	{
		Debug.Log("FriendLobby.OnTogetherFriendButtonClicked()");
		if (togetherFriend == null)
			return;

		m_TogetherFriend = togetherFriend;

		//  If the previous screen was the 'GameInstance' screen, then invite the User to the GameInstance.
		if (FriendLobby.PreviousScreen == "GameInstance")
		{
			m_GameInstance = Helper.UserData as PlaysTogether.GameInstance;

			InviteTogetherFriendToGameInstance();
		}

		//  If the previous screen was the 'ChatRoom' screen, then invite the User to the ChatRoom.
		else if (FriendLobby.PreviousScreen == "ChatRoom")
		{
			m_ChatRoom = Helper.UserData as PlaysTogether.ChatRoom;

			InviteTogetherFriendToChatRoom();
		}
	}
	
	//  Invites a TogetherFriend to a GameInstance.
	void InviteTogetherFriendToGameInstance()
	{
		PlaysTogether.PropertyCollection gameInstanceUserProperties = new PlaysTogether.PropertyCollection();
		gameInstanceUserProperties.Set("Score", "0");
			
		string notificationMessage = "";//Together.Instance.GetUsername() + " has invited you to play a game!";
			
			
		m_GameInstance.InviteUser(m_TogetherFriend.UserID,					// inviteeUserID
								  "",										// inviteeSocialType
								  "",										// inviteeSocialID
								  gameInstanceUserProperties,				// gameUserProperties
								  notificationMessage,						// notificationMessage
								  onInviteTogetherFriendToGameInstance);	// callbackFunc
	}
	void onInviteTogetherFriendToGameInstance(PlaysTogether.TogetherCallback tcb)
	{
		if (tcb.Success)
		{
			OnBackButtonClicked();
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}



	//  Invites a TogetherFriend to a ChatRoom.
	void InviteTogetherFriendToChatRoom()
	{
		string notificationMessage = Together.Instance.GetUsername() + " has invited you to a chat room!";
			
			
		m_ChatRoom.InviteUser(m_TogetherFriend.UserID,						// inviteeUserID
							  "",											// inviteeSocialType
							  "",											// inviteeSocialID
							  notificationMessage,							// notificationMessage
							  onInviteTogetherFriendToChatRoom);			// callbackFunc
	}
	void onInviteTogetherFriendToChatRoom(PlaysTogether.TogetherCallback tcb)
	{
		if (tcb.Success)
		{
			OnBackButtonClicked();
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	
	
	
	
	
	
	
	
	
	

	void OnFacebookFriendButtonClicked(PlaysTogether.ExternalFriend facebookFriend)
	{
		Debug.Log("FriendLobby.OnFacebookFriendButtonClicked()");
		
		if (facebookFriend == null)
			return;

		m_FacebookFriend = facebookFriend;

		//  If the previous screen was the 'GameInstance' screen, then send a Facebook Post to the user
		//  inviting them to the GameInstance.
		if (FriendLobby.PreviousScreen == "GameInstance")
		{
			m_GameInstance = Helper.UserData as PlaysTogether.GameInstance;

			InviteFacebookFriendToGameInstance();
		}

		//  If the previous screen was the 'ChatRoom' screen, then invite the User to the ChatRoom.
		else if (FriendLobby.PreviousScreen == "ChatRoom")
		{
			m_ChatRoom = Helper.UserData as PlaysTogether.ChatRoom;

			InviteFacebookFriendToChatRoom();
		}
	}

	
	
	//  Invites a FacebookFriend to a GameInstance.
	void InviteFacebookFriendToGameInstance()
	{
		PlaysTogether.PropertyCollection gameInstanceUserProperties = new PlaysTogether.PropertyCollection();
		gameInstanceUserProperties.Set("Score", "0");
			
		string notificationMessage = Together.Instance.GetUsername() + " has invited you to play a game!";
			

		m_GameInstance.InviteUser(0,										// inviteeUserID
								  "FB",										// inviteeSocialType
								  m_FacebookFriend.FriendID,				// inviteeSocialID
								  gameInstanceUserProperties,				// gameUserProperties
								  notificationMessage,						// notificationMessage
								  onInviteFacebookFriendToGameInstance);	// callbackFunc
	}
	void onInviteFacebookFriendToGameInstance(PlaysTogether.TogetherCallback e)
	{
		if (e.Success)
		{
			string postMessage = Together.Instance.GetUsername() + " has invited you play a game!";

			SendPostToFacebookUser(m_FacebookFriend.FriendID,										// facebookFriendID
								   "Together Tic-Tac-Toe",											// postTitle
								   postMessage,														// postMessage
								   "http://www.google.com",											// postLink
								   "http://api.v1.playstogether.com/Images/TicTacToe/Icon-72.png",		// postPictureLink
								   onSendPostToFacebookUser);										// callbackFunc
		}
	}



	//  Invites a FacebookFriend to a ChatRoom.
	void InviteFacebookFriendToChatRoom()
	{
		string notificationMessage = "";//Together.Instance.GetUsername() + " has invited you to a chat room!";
		
		Debug.Log("Sending post");
		
		// Invite the User to the ChatRoom.
		m_ChatRoom.InviteUser(0,										// inviteeUserID
							  "FB",										// inviteeSocialType
							  m_FacebookFriend.FriendID,				// inviteeSocialID
							  notificationMessage,						// notificationMessage
							  onInviteFacebookFriendToChatRoom);		// callbackFunc
	}
	public void onPostedToFriend(TogetherCallback e)
	{
		Debug.Log("onPostedToFriend()\nSuccess=" + e.Success + "\nMessage=" + e.Message + "\nStatus=" + e.Status);
	}
	
	void onInviteFacebookFriendToChatRoom(PlaysTogether.TogetherCallback e)
	{
		if (e.Success)
		{
			string postMessage = Together.Instance.GetUsername() + " has invited you to a chat room!";

			SendPostToFacebookUser(m_FacebookFriend.FriendID,											// facebookFriendID
								   "Together Tic-Tac-Toe",											// postTitle
								   postMessage,														// postMessage
								   "http://www.google.com",											// postLink
								   "http://api.v1.playstogether.com/Images/TicTacToe/Icon-72.png",		// postPictureLink
								   onSendPostToFacebookUser);										// callbackFunc
		}
	}
	

	
	void SendPostToFacebookUser(string facebookFriendID,
								string postTitle,
								string postMessage,
								string postLink,
								string postPictureLink,
								PlaysTogether.OnCompleteHandler callbackFunc)
	{
		
		
		
	}
	void onSendPostToFacebookUser(PlaysTogether.TogetherCallback e)
	{
		OnBackButtonClicked();
	}

}
