using UnityEngine;
using System.Collections;
using PlaysTogether;

public class ChatRoomLobby : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private bool m_bDisplay = false;
	private PlaysTogether.ChatRoom[] m_chatRooms;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		Together.Instance.ChatRoomManager.GetAll(0, onGotAllChatRooms);
	}
	
	void onGotAllChatRooms(TogetherCallback tcb)
	{
		if(tcb.Success)
		{	
			m_bDisplay = true;
			
			int count = Together.Instance.ChatRoomManager.GetCount();
			Debug.Log("Chat room count " + count);
			if(count > 10)
				count = 10;

			m_chatRooms = new PlaysTogether.ChatRoom[count];
			
			for (int i = 0; i < count; i++) 
				m_chatRooms[i] = Together.Instance.ChatRoomManager.Get(i);
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		
		DisplayButtons();
	}
	
	void DisplayText()
	{
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 15, 300,100), "Chat Room Lobby", m_TitleStyle);	
	}
	
	void DisplayButtons()
	{
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");
		
		if( GUI.Button(new Rect(10, 110, 100, 50), "Create Room"))
		{
			Debug.Log("Create room");	//Hack need to put in properties
			Together.Instance.ChatRoomManager.Create("TicTacToeTest", 			// name
													 "Tic Tac Toe Chat!",		// description
													 0,							// roomID
													 0,							// gameInstanceID
													 false,						// joinChatRoom
													 null,						// chatRoomProperties
													 onCreatedRoom);			// callbackFunc
		}
		//if( GUI.Button(new Rect((Screen.width - 200) * 0.5f, 200, 200, 50), "ChatRoom1"))
		//	Application.LoadLevel("ChatRoom");

		if (m_bDisplay)
		{	
			for (int i = 0; i < m_chatRooms.Length; i++) 
			{
				string display = "ID= " + m_chatRooms[i].ChatRoomID + ", Name=" + m_chatRooms[i].Name;
				if( GUI.Button(new Rect((Screen.width - 400) * 0.5f, 200 +(60 * i), 400, 50), display))
				{
					Helper.UserData = m_chatRooms[i];
					Application.LoadLevel("ChatRoom");
				}
			}
		}
	}
	void onCreatedRoom(TogetherCallback tcb)
	{
		Debug.Log("***************************************");
		Debug.Log("*******   onCreatedRoom");
		Debug.Log("***************************************");
		
		if (tcb.Success)
			Together.Instance.ChatRoomManager.GetAll(0, onGotAllChatRooms);
	}
}
