using UnityEngine;
using System.Collections;
using PlaysTogether;

public class Login : MonoBehaviour 
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private GUIStyle m_popUp;
	//private bool m_bLoggedIn = false;
	
	// Use this for initialization
	void Start () 
	{
		/*if (Together.Instance == null)
		{
			Debug.Log("started");	
			Helper.Initialize();
		}*/
		
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		
		//Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		string serverIP = Together.Instance.ServerIP;
		
		//Create and set our labels
		GUI.Label(new Rect((Screen.width - 200) * 0.5f, 15, 200, 100), "Login Scene", m_TitleStyle);
		GUI.Label(new Rect((Screen.width - 400) * 0.5f, 250, 400, 300), "ServerIP = " + serverIP, m_TextStyle);
		
		//Create and set the login button
		if( GUI.Button(new Rect((Screen.width - 100) * 0.5f, (Screen.height - 100 ) * 0.5f, 100, 50), "Login"))
		{
			Debug.Log("Login:  Logging in User.");
			LoginUser();
		}
	}
	
	public void LoginUser()
	{
		Together.Instance.LoginUser(onLoggedIn);
	}
	public void onLoggedIn(PlaysTogether.TogetherCallback tcb)
	{	
		Debug.Log("onLoggedIn "+ tcb);
		if (tcb.Success)
		{
			Debug.Log("  Successfully logged in the user.");
			Application.LoadLevel("MainMenu"); //m_bLoggedIn = true;
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void onLoginCB()
	{
		Application.LoadLevel("MainMenu");
	}
	
}
