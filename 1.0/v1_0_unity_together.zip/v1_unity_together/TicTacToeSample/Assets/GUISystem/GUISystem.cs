using UnityEngine;
using System.Collections;

public class GUISystem : MonoBehaviour {
	
	[SerializeField] private MonoBehaviour[] m_Listeners;
	
	// Use this for initialization
	void Start () 
	{
		Debug.Log("Start");
		
	}
	
	// Update is called once per frame
	void Update () 
	{
		RaycastHit hitInfo;
		
		Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			
		//This will cause the mouse to send a ray into the world. If there is a hit it will return true
		if(Physics.Raycast(ray, out hitInfo, Mathf.Infinity))//, ~LayerMask.NameToLayer("GUI")) == true)
		{
			Debug.Log("RayCastOver");
			//The name of the object that is hit
			foreach(MonoBehaviour mb in m_Listeners)
			{
				mb.SendMessage("OnMouseOver", hitInfo.transform.gameObject.name, SendMessageOptions.DontRequireReceiver);
			}
		}
	}
}
