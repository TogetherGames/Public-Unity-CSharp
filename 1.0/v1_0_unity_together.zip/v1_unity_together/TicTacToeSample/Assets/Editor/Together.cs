using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.IO;

public class Together : EditorWindow
{
	// Supported
	private string[] PLATFORMS = new string[] {
		"iOS", "Android", "Web Player", "Mac OS X", "Windows", "Windows 64-bit" };
		
	private string _publicKey = "";
	private string _privateKey = "";
	private string _gameKey = "";
	private int _platform = 0;
	
	[MenuItem("Window/Together")]
	public static void Open()
	{
		EditorWindow.GetWindow<Together>();
	}
	
	private void OnEnable()
	{
		_publicKey = EditorPrefs.GetString("togetherPublicKey");
		_privateKey = EditorPrefs.GetString("togetherPrivateKey");
		_gameKey = EditorPrefs.GetString("togetherGameKey");
		_platform = EditorPrefs.GetInt("togetherPlatform");
	}
	
	private void OnLostFocus()
	{
		OnDisable();
	}
	
	private void OnDisable()
	{
		EditorPrefs.SetString("togetherPublicKey", _publicKey);
		EditorPrefs.SetString("togetherPrivateKey", _privateKey);
		EditorPrefs.SetString("togetherGameKey", _gameKey);
		EditorPrefs.SetInt("togetherPlatform", _platform);
		EditorPrefs.SetString("togetherPlatformName", PLATFORMS[_platform]);
	}
	
	private void OnGUI()
	{
		GUI.Label(new Rect(10f, 10f, 70f, 20f), "Public Key:");
		_publicKey = GUI.TextField(new Rect(80f, 10f, 300f, 20f), _publicKey);
		
		GUI.Label(new Rect(10f, 40f, 70f, 20f), "Private Key:");
		_privateKey = GUI.TextField(new Rect(80f, 40f, 300f, 20f), _privateKey);
		
		GUI.Label(new Rect(10f, 70f, 70f, 20f), "Game Key:");
		_gameKey = GUI.TextField(new Rect(80f, 70f, 300f, 20f), _gameKey);
		
		if(GUI.Button(new Rect(220f, 120f, 20f, 20f), "<"))
		{
			if(--_platform < 0)
				_platform = (PLATFORMS.Length-1);
		}
		
		if(GUI.Button(new Rect(240f, 120f, 20f, 20f), ">"))
		{
			if(++_platform >= PLATFORMS.Length)
				_platform = 0;
		}
		
		GUI.Box(new Rect(100f, 120f, 110f, 20f), "");
		GUI.Label(new Rect(105f, 122f, 110f, 20f), PLATFORMS[_platform]);
		
		if(GUI.Button(new Rect(10f, 120f, 70f, 20f), "Build"))
			Build();
	}
	
	private void Build()
	{
		bool showWarning = (
			(PLATFORMS[_platform] == "iOS" && EditorUserBuildSettings.activeBuildTarget != BuildTarget.iPhone) ||
			(PLATFORMS[_platform] == "Android" && EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android) ||
			(PLATFORMS[_platform] == "Web Player" && EditorUserBuildSettings.activeBuildTarget != BuildTarget.WebPlayer) ||
			(PLATFORMS[_platform] == "Mac OS X" && EditorUserBuildSettings.activeBuildTarget != BuildTarget.StandaloneOSXIntel) ||
			(PLATFORMS[_platform] == "Windows" && EditorUserBuildSettings.activeBuildTarget != BuildTarget.StandaloneWindows) ||
			(PLATFORMS[_platform] == "Windows 64-bit" && EditorUserBuildSettings.activeBuildTarget != BuildTarget.StandaloneWindows64)
		);
		
		if(showWarning)
		{
			int cancel = EditorUtility.DisplayDialogComplex(
				"Together",
					"You have chosen to build for " + PLATFORMS[_platform] +
					" but that is not your current build target. Do you wish to build for " +
					PLATFORMS[_platform] + " anyway?",
				"Continue Build", "Cancel", "");
				
			if(cancel == 1)
				return;
		}
		
		int err = -1;
		
		if(_publicKey == "")
		{
			err = EditorUtility.DisplayDialogComplex("Together",
				"You must supply your Public Key in the field above to perform a build.\n\n " +
				"You can find your Public Key by logging in to the developers' portal then selecting Account from the dashboard.",
				"OK", "Visit Portal", "");
				
			if(err == 1)
				Application.OpenURL("http://developer.playstogether.com");
				
			return;
		}
		
		if(_privateKey == "")
		{
			err = EditorUtility.DisplayDialogComplex("Together",
				"You must supply your Private Key in the field above to perform a build.\n\n" +
				"You can find your Private Key by logging in to the developers' portal and then selecting Account from the dashboard.",
				"OK", "Visit Portal", "");
				
			if(err == 1)
				Application.OpenURL("http://developer.playstogether.com");
				
			return;
		}
		
		if(_gameKey == "")
		{
			err = EditorUtility.DisplayDialogComplex("Together",
				"You must supply your Game Key in the field above to perform a build.\n\n" +
				"You can find your Game Key by logging in to the developers' portal and then selecting this game from the dashboard.",
				"OK", "Visit Portal", "");
				
			if(err == 1)
				Application.OpenURL("http://developer.playstogether.com");
	
			return;
		}
		
		switch(PLATFORMS[_platform])
		{
			case "iOS":				PerformBuild_iOS();			break;
			case "Android":			PerformBuild_Android();		break;
			case "Web Player":		PerformBuild_Web();			break;
			case "Mac OS X":		PerformBuild_Mac();			break;
			case "Windows":			PerformBuild_Win32();		break;
			case "Windows 64-bit":	PerformBuild_Win64();		break;
			default:
				EditorUtility.DisplayDialog("Together",
					"Invalid platform targeted. Build cannot be performed.",
					"OK" );
				break;
		}
	}
	
	private void PerformBuild_iOS()
	{
		List<string> allScenes = new List<string>();
		
		foreach(EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
		{
			if(scene.enabled)
				allScenes.Add(scene.path);
		}
		
		// Build the XCode Project
		BuildPipeline.BuildPlayer(
			allScenes.ToArray(),
			EditorUserBuildSettings.GetBuildLocation(BuildTarget.iPhone),
			BuildTarget.iPhone,
			BuildOptions.ShowBuiltPlayer );
		
		
		// Post Process the info.plist
		FileStream fs = File.OpenRead(EditorUserBuildSettings.GetBuildLocation(BuildTarget.iPhone) + "/info.plist");
		StreamReader sr = new StreamReader(fs);
		string contents = sr.ReadToEnd();
		
		sr.Close();
		fs.Close();
		
		string pre = contents.Substring(0, contents.IndexOf("</dict>") );
		
		string post =
		"\t<key>CFBundleURLTypes</key>\n" +
		"\t<array>\n" +
		"\t\t<dict>\n" +
		"\t\t\t<key>CFBundleURLSchemes</key>\n" +
		"\t\t\t<array>\n" +
		"\t\t\t\t<string>" + _gameKey.ToUpper() + "</string>\n" +
		"\t\t\t</array>\n" +
		"\t\t\t<key>CFBundleURLName</key>\n" +
		"\t\t\t<string>" + PlayerSettings.bundleIdentifier.ToLower() + "</string>\n" +
		"\t\t</dict>\n" +
		"\t</array>\n";
		
		pre += (post + contents.Substring(contents.IndexOf("</dict>")));
		
		// Save over
		fs = File.OpenWrite(EditorUserBuildSettings.GetBuildLocation(BuildTarget.iPhone) + "/info.plist");
						
		System.Text.ASCIIEncoding  encoding = new System.Text.ASCIIEncoding();
		byte[] bytes = encoding.GetBytes(pre);
		
		fs.Write(bytes, 0, pre.Length);
		
		fs.Close();
	}
	
	private void PerformBuild_Android()
	{
		// For android we have a manifest we need
		// to update before building
		FileStream fs = File.OpenRead("Assets/Plugins/Android/AndroidManifest.xml");
		StreamReader sr = new StreamReader(fs);
		string contents = sr.ReadToEnd();
		
		sr.Close();
		fs.Close();
		
		contents.Replace("{PACKAGE}", PlayerSettings.bundleIdentifier.ToLower());
		contents.Replace("{GAMEKEY}", _gameKey.ToUpper());
		
		// Save over
		fs = File.OpenWrite("Assets/Plugins/Android/AndroidManifest.xml");
						
		System.Text.ASCIIEncoding  encoding = new System.Text.ASCIIEncoding();
		byte[] bytes = encoding.GetBytes(contents);
		
		fs.Write(bytes, 0, contents.Length);
		
		fs.Close();
		
		// Lastly build
		List<string> allScenes = new List<string>();
		
		foreach(EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
		{
			if(scene.enabled)
				allScenes.Add(scene.path);
		}
		
		// Build the APK
		BuildPipeline.BuildPlayer(
			allScenes.ToArray(),
			EditorUserBuildSettings.GetBuildLocation(BuildTarget.Android),
			BuildTarget.Android,
			BuildOptions.ShowBuiltPlayer );
	}
	
	private void PerformBuild_Web()
	{
		List<string> allScenes = new List<string>();
		
		foreach(EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
		{
			if(scene.enabled)
				allScenes.Add(scene.path);
		}
		
		BuildPipeline.BuildPlayer(
			allScenes.ToArray(),
			EditorUserBuildSettings.GetBuildLocation(BuildTarget.WebPlayer),
			BuildTarget.WebPlayer,
			BuildOptions.ShowBuiltPlayer );
	}
	
	private void PerformBuild_Mac()
	{
		List<string> allScenes = new List<string>();
		
		foreach(EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
		{
			if(scene.enabled)
				allScenes.Add(scene.path);
		}
		
		BuildPipeline.BuildPlayer(
			allScenes.ToArray(),
			EditorUserBuildSettings.GetBuildLocation(BuildTarget.StandaloneOSXIntel),
			BuildTarget.StandaloneOSXIntel,
			BuildOptions.ShowBuiltPlayer );
	}
	
	private void PerformBuild_Win32()
	{
		List<string> allScenes = new List<string>();
		
		foreach(EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
		{
			if(scene.enabled)
				allScenes.Add(scene.path);
		}
		
		BuildPipeline.BuildPlayer(
			allScenes.ToArray(),
			EditorUserBuildSettings.GetBuildLocation(BuildTarget.StandaloneWindows),
			BuildTarget.StandaloneWindows,
			BuildOptions.ShowBuiltPlayer );
	}
	
	private void PerformBuild_Win64()
	{
		List<string> allScenes = new List<string>();
		
		foreach(EditorBuildSettingsScene scene in EditorBuildSettings.scenes)
		{
			if(scene.enabled)
				allScenes.Add(scene.path);
		}
		
		BuildPipeline.BuildPlayer(
			allScenes.ToArray(),
			EditorUserBuildSettings.GetBuildLocation(BuildTarget.StandaloneWindows64),
			BuildTarget.StandaloneWindows64,
			BuildOptions.ShowBuiltPlayer );
	}
}
