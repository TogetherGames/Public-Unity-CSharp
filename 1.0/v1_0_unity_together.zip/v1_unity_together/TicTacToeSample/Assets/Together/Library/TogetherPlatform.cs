using UnityEngine;
//using UnityEditor;
using System.Collections;
using PlaysTogether;
	
public class TogetherPlatform : MonoBehaviour
{
	private static TogetherPlatform _instance = null;
	
	private static bool _initialized = false;
	private static PlaysTogether.Together _together;
	
	public string PublicKey = "";
	public string PrivateKey = "";
	public string GameKey = "";
	public string FacebookAppID = "";
	public bool PushServiceEnabled = false;
	private TogetherFacebook _fb = null;
	
	private void Start()
	{
		if(_instance != null)
			GameObject.Destroy(gameObject);
		else
		{
			DontDestroyOnLoad(this);
			
			Initialize();
			
			if(FacebookAppID != "")
			{
				_fb = (TogetherFacebook)gameObject.AddComponent(typeof(TogetherFacebook));
				_fb.Initialize(FacebookAppID);
				DontDestroyOnLoad(_fb);
			}
			
			if(PushServiceEnabled)
			{
				TogetherDeviceRegistrar reg = (TogetherDeviceRegistrar)gameObject.AddComponent(typeof(TogetherDeviceRegistrar));
				reg.Initialize();
			}
		}
	}
	
	private void Initialize()
	{
		if(!_initialized)
		{
			_instance = this;
			PlaysTogether.Log.Instance = new TogetherLog();
			PlaysTogether.CacheFile.Instance = new TogetherCache();
			((TogetherCache)PlaysTogether.CacheFile.Instance).PersistentDataPath = Application.persistentDataPath;
	
			//Store an instance of the together platform
			_together = new Together(false);
			_together.Initialize(PublicKey, PrivateKey, GameKey, "iOS");
			_together.SetServerAddress("http://api.v1.playstogether.com");
			_together.LoadTogetherCache();
			_initialized = true;
		}
	}
	
	private void Update() 
	{
		PlaysTogether.NetworkProcessor.Process();
	}
}
