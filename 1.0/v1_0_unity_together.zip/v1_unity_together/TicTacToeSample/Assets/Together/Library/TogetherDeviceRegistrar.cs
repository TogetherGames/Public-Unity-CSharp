using UnityEngine;
using System.Collections;
using PlaysTogether;

public class TogetherDeviceRegistrar : MonoBehaviour
{
	private byte[] _token = null;
	
	public void Initialize()
	{
#if UNITY_IPHONE
		Debug.Log ("Registering device...");
		NotificationServices.RegisterForRemoteNotificationTypes(
			RemoteNotificationType.Alert | RemoteNotificationType.Badge | RemoteNotificationType.Sound);
#endif
	}
	
	private void Update()
	{
#if UNITY_IPHONE
		string regErr = NotificationServices.registrationError;
		if(regErr != null && regErr != "")
		{
			Debug.Log ("Device Registration Error: " + regErr);
			Destroy(this);
			return;
		}
		
		if(Together.Instance != null && Together.Instance.UserSession != null)
		{
			_token = NotificationServices.deviceToken;
			if(_token != null)
			{
				string hexToken = System.BitConverter.ToString(_token).Replace("-", "");
				Together.Instance.ApnsDeviceToken = hexToken;
				Together.Instance.RegisterPushEnabledDevice(null);
				Destroy(this);
			}
		}
#endif		
	}
}
