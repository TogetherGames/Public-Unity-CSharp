using UnityEngine;
using System;
using System.IO;
using PlaysTogether;

public class TogetherCache : CacheFile
{
	protected string _PersistentDataPath;
	
	public string PersistentDataPath { get { return _PersistentDataPath; } set { _PersistentDataPath = value; } }


	public TogetherCache()
	{
		_PersistentDataPath = "";
	}

		
		
	//  Loads the CacheFile.
	public override bool Load(string filename)
	{
		try
		{
			string cacheFilename = _PersistentDataPath + "/" + filename;
			
			if(!File.Exists(cacheFilename))
			{
				StreamWriter sw = File.CreateText(cacheFilename);
				if(sw != null)
					sw.Close();
			}
			
			StreamReader fileReader = File.OpenText(cacheFilename);
			this.UserGuid = fileReader.ReadLine();
 			fileReader.Close();
 				
 			return true;
 		}
 		catch (Exception e)
 		{
 			Log.Write("Exception:");
 			Log.Write("Message = " + e.Message);
 			Log.Write("StackTrace = " + e.StackTrace);
 		}
 
		return false;
	}
		
	//  Saves the CacheFile.
	public override bool Save(string filename)
	{
		try
		{
			string cacheFilename = _PersistentDataPath + "/" + filename;
 			Debug.Log ("cacheFilename = " + cacheFilename);
 			StreamWriter fileWriter = File.CreateText(cacheFilename);
 			fileWriter.WriteLine(this.UserGuid);
 			fileWriter.Close();
 				
 			return true;
 		}
 		catch (Exception e)
 		{
 			Log.Write("Exception:");
 			Log.Write("Message = " + e.Message);
 			Log.Write("StackTrace = " + e.StackTrace);
 		}
 
 		return false;
	}
		
	//  Erases the CacheFile.
	public override bool Erase(string filename)
	{
		Debug.Log("CacheFileUnity.Erase(" + filename + ")");
		try
		{
			string cacheFilename = _PersistentDataPath + "/" + filename;
 			if (File.Exists(cacheFilename))
 			{
 				Debug.Log("   Deleting cache file.");
 				File.Delete(cacheFilename);
// 			StreamWriter fileWriter = File.CreateText(cacheFilename);
// 			fileWriter.Close();
 			}
 
 			return true;
 		}
 		catch (Exception e)
 		{
 			Log.Write("Exception:");
 			Log.Write("Message = " + e.Message);
 			Log.Write("StackTrace = " + e.StackTrace);
 		}
 
		return false;
	}
}

