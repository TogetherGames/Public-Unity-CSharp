using UnityEngine;
using System.Collections;
using PlaysTogether;

public class UserItemsLobby : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private bool m_bDisplay = false;
	private int textWidth = 500;
	private int buttonWidth = 400;
	private PlaysTogether.UserItem[] m_userItems;
	
	// Use this for initialization
	void Start () 
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		Together.Instance.User.UserItemManager.GetAll(onGotAllUserItems);		// callbackFunc
	}
	
	void onGotAllUserItems(TogetherCallback tcb)
	{
		Debug.Log("onGotAllUserItems " + tcb);
		if(tcb.Success)
		{	
			m_bDisplay = true;
			
			int count = Together.Instance.User.UserItemManager.GetCount();
			Debug.Log("user item count " + count);
			if(count > 7)
				count = 7;

			m_userItems = new PlaysTogether.UserItem[count];
			
			for (int i = 0; i < count; i++) 
				m_userItems[i] = Together.Instance.User.UserItemManager.Get(i);
		}
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		
		DisplayButtons();
	}
	
	void DisplayText()
	{
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, 15, textWidth, 100), "User Items Lobby", m_TitleStyle);	
		
	}
	
	void DisplayButtons()
	{
		if( GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("MainMenu");
		
		//if( GUI.Button(new Rect((Screen.width - 200) * 0.5f, (Screen.height - 50 ) * 0.5f, 200, 50), "UserItem1"))
		//	Application.LoadLevel("UserItem");
				
		if(m_bDisplay)
		{	
			for (int i = 0; i < m_userItems.Length; i++) 
			{
				string display = "ID= " + m_userItems[i].UserItemID + ", Name=" + m_userItems[i].Item.Name;
				if (GUI.Button(new Rect((Screen.width - buttonWidth) * 0.5f, 200 + (60 * i), buttonWidth, 50), display))
				{	
					Helper.UserData = m_userItems[i];
					Application.LoadLevel("UserItem");
				}
			}
		}
	}
}
