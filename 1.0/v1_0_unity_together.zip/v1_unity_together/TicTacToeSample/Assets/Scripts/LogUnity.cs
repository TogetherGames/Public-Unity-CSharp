using UnityEngine;
using PlaysTogether;

public class LogUnity : Log
{

	public LogUnity()
	{
		_enabled = true;
	}
	
	public override void Print(string msg)
	{
		if (_enabled)
			Debug.Log(msg);
	}
}
