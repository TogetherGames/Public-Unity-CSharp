using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using PlaysTogether;

public class Item : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private PlaysTogether.Item m_Item;
	private int textWidth = 500;

	// Use this for initialization
	void Start () 
	{
		m_Item = Helper.UserData as PlaysTogether.Item;
		
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
	}

	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayText();
		DisplayButtons();
	}
	
	void DisplayText()
	{
		int labelY = 65;
		int labelYStep = 30;

		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, 15, textWidth, 100), "Item", m_TitleStyle);
		
		//Create and set the labels
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "ItemID = " + m_Item.ItemID, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Type = " + m_Item.ItemType, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Name = " + m_Item.Name, m_TextStyle);	
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), "Description = " + m_Item.Description, m_TextStyle);	
		labelY += labelYStep;

		// Display all the Item properties.
		Debug.Log("m_Item.Properties = " + m_Item.Properties);
		Debug.Log("m_Item.Properties.Properties = " + m_Item.Properties.Properties);

		if (m_Item.Properties.Properties != null)
		{
			foreach (Property property in m_Item.Properties.Properties)
			{
				GUI.Label(new Rect((Screen.width - textWidth) * 0.5f, labelY, textWidth, 100), property.Name + " = " + property.Value, m_TextStyle);
				labelY += labelYStep;
			}
		}
	}
	
	void DisplayButtons()
	{
		//Create and set the buttons
		if (GUI.Button(new Rect(10, 50, 100, 50), "Back"))
			Application.LoadLevel("ItemsLobby");
		
		if (GUI.Button(new Rect((Screen.width - 100) * 0.5f, Screen.height - 260, 100, 50), "Award"))
		{
			Debug.Log("Award");
			OnAwardButtonClicked();
		}
		if (GUI.Button(new Rect((Screen.width - 100) * 0.5f, Screen.height - 200, 100, 50), "Create"))
		{
			Debug.Log("Create");
			OnCreateButtonClicked();
		}
		if (GUI.Button(new Rect((Screen.width - 100) * 0.5f, Screen.height - 140, 100, 50), "Purchase"))
		{
			Debug.Log("Purchase");
			OnPurchaseButtonClicked();
		}
	}
	
	void OnAwardButtonClicked()
	{
		Together.Instance.User.UserItemManager.Award(m_Item.ItemID,				// itemID
													 0,							// roomID
													 m_Item.Properties,			// userItemProperties,
													 onUserItemAwarded);		// callbackFunc
	}
	
	void OnCreateButtonClicked()
	{
		Together.Instance.User.UserItemManager.Create(m_Item.ItemID, 			// itemID
													  0, 						// roomID
													  m_Item.Properties,		// userItemProperties
													  onUserItemCreated);		// callbackFunc
	}
	
	void OnPurchaseButtonClicked()
	{
		Together.Instance.User.UserItemManager.Purchase(m_Item.ItemID,			// itemID
														0,						// roomID
														null,//m_Item.Properties,		// userItemProperties
														false,					// useGameUserProfileProperties											
														onUserItemPurchased);	// callbackFunc
	}

	void onUserItemAwarded(TogetherCallback tcb)
	{
		if (tcb.Success)
			Application.LoadLevel ("ItemsLobby");
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}

	void onUserItemCreated(TogetherCallback tcb)
	{
		if (tcb.Success)
			Application.LoadLevel ("ItemsLobby");
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}

	void onUserItemPurchased(TogetherCallback tcb)
	{
		if (tcb.Success)
			Application.LoadLevel ("ItemsLobby");
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}

	void onUserItemsReloaded(TogetherCallback tcb)
	{
		if (tcb.Success)
			Application.LoadLevel("ItemsLobby");
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
}
