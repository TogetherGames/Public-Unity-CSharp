using UnityEngine;
using System.Collections;
using PlaysTogether;

public class MainMenu : MonoBehaviour
{
	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	
	private PlaysTogether.User m_User;
	private int m_Coins;
	private string m_Cash;
	private int m_Stars;
	private int m_Score;

	
	// Use this for initialization
	void Start () 
	{
		if (Log.Instance != null)
			Debug.Log ("Log.Instance = (not null)");
		else
			Debug.Log ("Log.Instance = (null)");

		Log.Write("MainMenu.Start()");

		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;
		
		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
		
		m_User = Together.Instance.User;

		refreshText();
	}

	// Update is called once per frame
	void Update () 
	{
	}
	
	void OnGUI()
	{
		DisplayButtons();
		DisplayText();
	}
	
	void DisplayButtons()
	{
		//Create and set our buttons
		if (GUI.Button(new Rect(10, 50, 100, 50), "Logout"))
			OnLogoutButtonClicked();
		
		if (GUI.Button(new Rect(10, 110, 100, 50), "Register"))
			Application.LoadLevel("Register");
		
		if (GUI.Button(new Rect((Screen.width - 140) * 0.5f,(Screen.height - 210 ) * 0.5f, 140, 50), "Game Lobby"))
		{
			Together.Instance.AddAnalytic("EnterMode", "GameLobby", "", null);
			Application.LoadLevel("GameLobby");
		}
		
		if (GUI.Button(new Rect(10, (Screen.height + 450 ) * 0.5f, 140, 50), "Create Notification"))
			OnCreateNotificationButtonClicked();
		
#if UNITY_IPHONE
		if (GUI.Button(new Rect((Screen.width - 150), (Screen.height + 450 ) * 0.5f, 140, 50), "Send Push"))
			OnSendPushButtonClicked();
#endif
		
		if (GUI.Button(new Rect((Screen.width - 110), 50, 100, 50), "Add Stats"))
			OnUpdateStatsButtonClicked();
		
		if (GUI.Button(new Rect((Screen.width - 140) * 0.5f,(Screen.height - 100) * 0.5f, 140, 50), "Leaderboards"))
			OnViewLeaderboardsButtonClicked();
		
		if (GUI.Button(new Rect((Screen.width - 140) * 0.5f,(Screen.height + 10 ) * 0.5f, 140, 50), "Achievements"))
			OnViewAchievementsButtonClicked();
		
		if (GUI.Button(new Rect((Screen.width - 140) * 0.5f,(Screen.height + 120 ) * 0.5f, 140, 50), "User Achievements"))
			OnViewUserAchievementsButtonClicked();
		
		if (GUI.Button(new Rect((Screen.width - 140) * 0.5f,(Screen.height + 230 ) * 0.5f, 140, 50), "Items"))
			OnViewItemsButtonClicked();
		
		if (GUI.Button(new Rect((Screen.width - 140) * 0.5f,(Screen.height + 340 ) * 0.5f, 140, 50), "User Items"))
			OnViewUserItemsButtonClicked();
		
		if (GUI.Button(new Rect((Screen.width - 140) * 0.5f,(Screen.height + 450 ) * 0.5f, 140, 50), "Chat Rooms"))
			OnViewChatRoomsButtonClicked();
		
		if (GUI.Button(new Rect((Screen.width - 140) * 0.5f,(Screen.height + 560) * 0.5f, 140, 50), "Wall Post"))
			OnWallPostButtonClicked();
		
		
	}
	
	void OnLogoutButtonClicked()
	{
		Debug.Log("CacheFile.Instance = " + CacheFile.Instance);
		CacheFile.Instance.Erase("TogetherCache.cache");
		Debug.Log("a;dslkfjasd;lfjasdf");
		TogetherFacebook.Instance.Logout(onLogoutOfFacebook);
	}
	
	void onLogoutOfFacebook(TogetherCallback tcb)
	{
		Application.LoadLevel("Login");		
	}

	void OnCreateNotificationButtonClicked()
	{
		Together.Instance.UserNotificationManager.Create(m_User.UserID,							//  destUserID
														 "Query",								//  type
														 "Notification sent from MainMenu.",	//  message
														 0,										//  originalGameInstanceID
														 0,										//  gameInstanceID
														 0,										//  achievementID
														 0,										//  chatRoomID
														 0,										//  itemID
														 0, 									//  itemCount
														 "",									//  socialType
														 "",									//  socialID
														 onCreatedUserNotification);			//  callbackFunc
	}
	
	void OnSendPushButtonClicked()
	{
		Together.Instance.SendPushNotification(
			Together.Instance.GetUserID(),
			"{\"aps\":{\"alert\":\"Push notification received!\"},\"acme2\":[\"bang\",\"whiz\"]}",
			onSendPushNotification );
	}
	
	void OnUpdateStatsButtonClicked()
	{
		int coins = int.Parse(m_User.Properties.GetEx("Coins", "0"));
		float cashValue;
		string cash = m_User.Properties.GetEx("Cash", "0.00");
		int stars = int.Parse(m_User.Properties.GetEx("Stars", "0"));
		int score = int.Parse(m_User.Properties.GetEx("Score", "0"));
	
		coins += 10;
		stars += 10;
		score += 10;
		cashValue = float.Parse(cash);
		cashValue += 10.0f;
		cash = "" + cashValue;

		m_User.Properties.Set ("Coins", coins.ToString());
		m_User.Properties.Set ("Stars", stars.ToString());
		m_User.Properties.Set ("Score", score.ToString());
		m_User.Properties.Set ("Cash", cash.ToString());
		
		Debug.Log("Modifying User...");
		Debug.Log("   Together.Instance = " + Together.Instance);
		Debug.Log("   Together.Instance.User = " + Together.Instance.User);
		Together.Instance.User.Modify(onUserModified);
	}
	
	void onUserModified(TogetherCallback tcb)
	{
		Debug.Log("onUserModified()");
		if (tcb.Success)
			refreshText();
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
	}
	
	void OnViewLeaderboardsButtonClicked()
	{
		Together.Instance.AddAnalytic("EnterMode", "LeaderboardLobby", "", null);
		Application.LoadLevel("LeaderboardsLobby");
	}
	
	void OnViewAchievementsButtonClicked()
	{
		Together.Instance.AddAnalytic("EnterMode", "ViewAllAchievements", "", null);
		Application.LoadLevel("AchievementsLobby");
	}
	
	void OnViewUserAchievementsButtonClicked()
	{
		Together.Instance.AddAnalytic("EnterMode", "ViewAllUserAchievements", "", null);
		Application.LoadLevel("UserAchievementsLobby");
	}
	
	void OnViewItemsButtonClicked()
	{
		Together.Instance.AddAnalytic("EnterMode", "ViewAllItems", "", null);
		Application.LoadLevel("ItemsLobby");
	}
	
	void OnViewUserItemsButtonClicked()
	{
		Together.Instance.AddAnalytic("EnterMode", "ViewAllUserItems", "", null);
		Application.LoadLevel("UserItemsLobby");
	}
	
	void OnViewChatRoomsButtonClicked()
	{
		Together.Instance.AddAnalytic("EnterMode", "ChatRoomLobby", "", null);
		Application.LoadLevel("ChatRoomLobby");
	}

	void OnWallPostButtonClicked()
	{
		Together.Instance.AddAnalytic("EnterMode", "FacebookWallPost", "", null);
		Application.LoadLevel("FacebookWallPost");
	}

	void refreshText()
	{
		if (Together.Instance.User != null)
		{
			m_Coins = int.Parse(m_User.Properties.GetEx("Coins", "0"));
			m_Cash = m_User.Properties.GetEx("Cash", "0.00");
			m_Stars = int.Parse(m_User.Properties.GetEx("Stars", "0"));
			m_Score = int.Parse(m_User.Properties.GetEx("Score", "0"));
		}
	}
	
	void onCreatedUserNotification(TogetherCallback tcb)
	{
		Debug.Log("onCreatedUserNotification");
		if (tcb.Success)
			Helper.Popup("Success", "Notification Sent", 0);
		else
			Helper.Popup("Uh oh", tcb.Message, 0);
		
	}
	
	void onSendPushNotification(TogetherCallback tcb)
	{
		Debug.Log ("onSendPushNotification");
		Debug.Log ("Success=" + tcb.Success);
	}
	
	void DisplayText()
	{
		int labelY = 60;
		int labelYStep = 22;

		//Create and set the labels
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, 15, 300, 100), "Main Menu Scene", m_TitleStyle);

		GUI.Label(new Rect((Screen.width - 500) * 0.5f, labelY, 500, 100), "UserGuid = " + m_User.UserGuid, m_TextStyle);
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "UserID = " + m_User.UserID, m_TextStyle);
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "UserName = " + m_User.Username, m_TextStyle);
		labelY += labelYStep;
		GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "Name = " + m_User.Name, m_TextStyle);
		labelY += labelYStep + 10;

		if (m_User.Properties != null)
		{
			GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "Coins = " + m_Coins, m_TextStyle);
			labelY += labelYStep;
			GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "Cash = " + m_Cash, m_TextStyle);
			labelY += labelYStep;
			GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "Stars = " + m_Stars, m_TextStyle);
			labelY += labelYStep;
			GUI.Label(new Rect((Screen.width - 300) * 0.5f, labelY, 300, 100), "Score = " + m_Score, m_TextStyle);
			labelY += labelYStep;
		}
	}
}
