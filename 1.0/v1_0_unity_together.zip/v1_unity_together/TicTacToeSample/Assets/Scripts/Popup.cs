using UnityEngine;
using System.Collections;

public class Popup : MonoBehaviour
{
	// Delegate callback method for button clicks.
    public delegate void PopupButtonClickedDelegate(string buttonText);

	private GUIStyle m_TitleStyle;
	private GUIStyle m_TextStyle;
	private Texture img;
	
	private string m_title;
	private string m_message = "";
	private string m_button1Text = "";
	private string m_button2Text = "";
	private int m_winID = 0;
	private Rect popupWin = new Rect((Screen.width - 500) * 0.5f, Screen.height - 300/*110*/, 500, 100);

	private PopupButtonClickedDelegate m_CallbackFunction = null;

	
	void Start()
	{
		//The color and style for my text
		m_TitleStyle = new GUIStyle();
		m_TitleStyle.normal.textColor = Color.white;
		m_TitleStyle.alignment = TextAnchor.UpperCenter;
		m_TitleStyle.fontSize = 32;

		m_TextStyle = new GUIStyle();
		m_TextStyle.normal.textColor = Color.white;
		m_TextStyle.alignment = TextAnchor.UpperCenter;
		m_TextStyle.fontSize = 18;
	}
	
	public void Initialize(string titleName, string message, string button1Text, string button2Text, int winID,
		PopupButtonClickedDelegate callbackFunction=null)
	{
		if (titleName == "")
			m_title = "Uh Oh";
		m_title = titleName;
		m_message = message;
		m_button1Text = button1Text;
		m_button2Text = button2Text;
		m_winID = winID;
		m_CallbackFunction = callbackFunction;
	}
	
	void OnGUI()
	{
		popupWin = GUI.Window(m_winID, popupWin, drawWindow, m_title);
	}
	
	void drawWindow(int id)
	{
		GUI.Label(new Rect(0, 20, 500,300), m_message, m_TextStyle);
		
		if (m_button2Text == "")
		{
			if (GUI.Button(new Rect(221, 70, 60, 25), m_button1Text))
			{
				if (m_CallbackFunction != null)
					m_CallbackFunction(m_button1Text);
				Destroy(this);
			}
		}
		else
		{
			if (GUI.Button(new Rect(140, 70, 60, 25), m_button1Text))
			{
				if (m_CallbackFunction != null)
					m_CallbackFunction(m_button1Text);
				Destroy(this);
			}
			
			if (GUI.Button(new Rect(300, 70, 60, 25), m_button2Text))
			{
				if (m_CallbackFunction != null)
					m_CallbackFunction(m_button2Text);
				Destroy(this);
			}
		}
	}
}
